from fastapi import APIRouter

from app.api.v1 import (
    admin,
    attendance,
    booth_codes,
    districts,
    me,
    phone_verifications,
    places,
    protocol,
    registrations,
    sessions,
    yatra_field,
    yatras,
)

api_router = APIRouter()
api_router.include_router(admin.router)
api_router.include_router(districts.router)
api_router.include_router(places.router)
api_router.include_router(booth_codes.router)
api_router.include_router(registrations.router)
api_router.include_router(phone_verifications.router)
api_router.include_router(sessions.router)
api_router.include_router(me.router)
api_router.include_router(attendance.router)
api_router.include_router(yatras.router)
api_router.include_router(yatra_field.router)
api_router.include_router(protocol.router)
