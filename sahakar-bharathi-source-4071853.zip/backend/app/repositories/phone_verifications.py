from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.phone_verification import PhoneVerification


class PhoneVerificationRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def get(self, challenge_id: uuid.UUID) -> PhoneVerification | None:
        # Lock the row so two confirms cannot both issue a registration token.
        return self.db.scalar(
            select(PhoneVerification)
            .where(PhoneVerification.id == challenge_id)
            .with_for_update()
        )

    def get_by_token_hash(self, token_hash: str) -> PhoneVerification | None:
        return self.db.scalar(
            select(PhoneVerification)
            .where(PhoneVerification.token_hash == token_hash)
            .with_for_update()
        )

    def for_mobile(self, mobile: str) -> list[PhoneVerification]:
        """All challenges for a mobile, newest first."""
        return list(
            self.db.scalars(
                select(PhoneVerification)
                .where(PhoneVerification.mobile == mobile)
                .order_by(PhoneVerification.created_at.desc())
            )
        )

    def retire_unused(self, rows: list[PhoneVerification], now: datetime) -> None:
        for row in rows:
            if row.consumed_at is None:
                row.consumed_at = now
            if row.token_used_at is None:
                row.token_used_at = now

    def add(self, challenge: PhoneVerification) -> PhoneVerification:
        self.db.add(challenge)
        return challenge
