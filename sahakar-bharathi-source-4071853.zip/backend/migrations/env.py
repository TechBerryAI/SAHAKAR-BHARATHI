import os
from logging.config import fileConfig

from alembic import context
from sqlalchemy import engine_from_config, pool

from app.core.config import get_settings, normalize_database_url
from app.db.base import Base
from app.models import (  # noqa: F401
    Attendance,
    AuditEvent,
    AuthSession,
    District,
    DistrictAdministrator,
    PhoneVerification,
    Place,
    ProtocolDocument,
    ProtocolItem,
    ProtocolTemplate,
    RateLimitBucket,
    Registration,
    User,
    Yatra,
    YatraAdministrator,
    YatraRoute,
    YatraStop,
)

config = context.config
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# MIGRATION_DATABASE_URL lets migrations use the table-owner credential while the
# running API uses a least-privilege DATABASE_URL (infra/supabase/runtime_role.sql).
# ConfigParser treats % as interpolation. URL-encoded passwords contain %XX.
_migration_url = normalize_database_url(os.environ.get("MIGRATION_DATABASE_URL", ""))
config.set_main_option(
    "sqlalchemy.url",
    (_migration_url or get_settings().sqlalchemy_url()).replace("%", "%%"),
)
target_metadata = Base.metadata


def run_migrations_offline() -> None:
    url = config.get_main_option("sqlalchemy.url")
    context.configure(url=url, target_metadata=target_metadata, literal_binds=True)
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    with connectable.connect() as connection:
        context.configure(connection=connection, target_metadata=target_metadata)
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
