from __future__ import annotations

from fastapi.testclient import TestClient
from sqlalchemy.engine import Engine

from app.core.config import get_settings
from app.core.rate_limit import SlidingWindowLimiter
from app.db import session as db_session
from app.main import create_app


def test_cors_allows_approved_origin_and_rejects_other(
    engine: Engine,
    database_url: str,
    monkeypatch,
) -> None:
    monkeypatch.setenv("CORS_ORIGINS", "https://web.example.com")
    monkeypatch.setenv("ENVIRONMENT", "development")
    get_settings.cache_clear()
    application = create_app()
    db_session.SessionLocal.configure(bind=engine)
    application.state.limiter = SlidingWindowLimiter()
    try:
        with TestClient(application) as client:
            allowed = client.options(
                "/api/v1/me",
                headers={
                    "Origin": "https://web.example.com",
                    "Access-Control-Request-Method": "GET",
                },
            )
            assert allowed.headers.get("access-control-allow-origin") == "https://web.example.com"
            denied = client.options(
                "/api/v1/me",
                headers={
                    "Origin": "https://evil.example",
                    "Access-Control-Request-Method": "GET",
                },
            )
            assert denied.headers.get("access-control-allow-origin") != "https://evil.example"
    finally:
        get_settings.cache_clear()
        application.state.limiter.reset()


def test_dev_preflight_allows_extra_headers_and_private_network(
    engine: Engine,
    monkeypatch,
) -> None:
    monkeypatch.setenv("CORS_ORIGINS", "http://localhost:5174")
    monkeypatch.setenv("ENVIRONMENT", "development")
    get_settings.cache_clear()
    application = create_app()
    db_session.SessionLocal.configure(bind=engine)
    application.state.limiter = SlidingWindowLimiter()
    try:
        with TestClient(application) as client:
            response = client.options(
                "/api/v1/sessions",
                headers={
                    "Origin": "http://localhost:5174",
                    "Access-Control-Request-Method": "POST",
                    "Access-Control-Request-Headers": "content-type, x-requested-with",
                    "Access-Control-Request-Private-Network": "true",
                },
            )
            assert response.status_code == 200
            assert response.headers.get("access-control-allow-origin") == "http://localhost:5174"
            assert response.headers.get("access-control-allow-private-network") == "true"
    finally:
        get_settings.cache_clear()
        application.state.limiter.reset()


def test_cors_allows_firebase_hosting_origin(
    engine: Engine,
    monkeypatch,
) -> None:
    monkeypatch.setenv(
        "CORS_ORIGINS",
        "https://sahakarbharati-e3b04.web.app,https://sahakarbharati-e3b04.firebaseapp.com",
    )
    monkeypatch.setenv("ENVIRONMENT", "development")
    get_settings.cache_clear()
    application = create_app()
    db_session.SessionLocal.configure(bind=engine)
    application.state.limiter = SlidingWindowLimiter()
    try:
        with TestClient(application) as client:
            allowed = client.options(
                "/api/v1/me",
                headers={
                    "Origin": "https://sahakarbharati-e3b04.web.app",
                    "Access-Control-Request-Method": "GET",
                },
            )
            assert (
                allowed.headers.get("access-control-allow-origin")
                == "https://sahakarbharati-e3b04.web.app"
            )
            alias = client.options(
                "/api/v1/me",
                headers={
                    "Origin": "https://sahakarbharati-e3b04.firebaseapp.com",
                    "Access-Control-Request-Method": "PATCH",
                },
            )
            assert (
                alias.headers.get("access-control-allow-origin")
                == "https://sahakarbharati-e3b04.firebaseapp.com"
            )
            denied = client.options(
                "/api/v1/me",
                headers={
                    "Origin": "https://evil.example",
                    "Access-Control-Request-Method": "GET",
                },
            )
            assert denied.headers.get("access-control-allow-origin") != "https://evil.example"
    finally:
        get_settings.cache_clear()
        application.state.limiter.reset()
