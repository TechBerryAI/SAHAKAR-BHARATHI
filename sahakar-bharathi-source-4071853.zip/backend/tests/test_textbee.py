from __future__ import annotations

import json

import httpx

from app.services.sms import TextbeeGateway


def test_textbee_posts_e164_recipient_and_device() -> None:
    captured: dict[str, object] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["url"] = str(request.url)
        captured["api_key"] = request.headers.get("x-api-key")
        captured["body"] = json.loads(request.content.decode())
        return httpx.Response(200, json={"data": {"success": True, "smsBatchId": "batch-1"}})

    gateway = TextbeeGateway(
        api_key="test-key",
        device_id="device-1",
        base_url="https://api.textbee.dev/api/v1",
        transport=httpx.MockTransport(handler),
    )
    gateway.send("+919876543210", "Sahakar Bharati verification code is 123456.")

    assert captured["url"] == "https://api.textbee.dev/api/v1/gateway/send-sms"
    assert captured["api_key"] == "test-key"
    assert captured["body"] == {
        "recipients": ["+919876543210"],
        "message": "Sahakar Bharati verification code is 123456.",
        "deviceId": "device-1",
    }


def test_textbee_omits_device_when_unset() -> None:
    captured: dict[str, object] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["body"] = json.loads(request.content.decode())
        return httpx.Response(200, json={"data": {"successCount": 1, "failureCount": 0}})

    TextbeeGateway(
        api_key="test-key",
        base_url="https://api.textbee.dev/api/v1/",
        transport=httpx.MockTransport(handler),
    ).send("+919876543210", "code")

    assert captured["body"] == {
        "recipients": ["+919876543210"],
        "message": "code",
    }


def test_textbee_sends_from_the_requested_sim() -> None:
    captured: dict[str, object] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["body"] = json.loads(request.content.decode())
        return httpx.Response(200, json={"data": {"success": True}})

    TextbeeGateway(
        api_key="test-key",
        device_id="device-1",
        sim_subscription_id=7,
        transport=httpx.MockTransport(handler),
    ).send("9876543210", "code")

    assert captured["body"]["simSubscriptionId"] == 7
    assert captured["body"]["recipients"] == ["9876543210"]


def test_textbee_uses_the_sim_that_has_service() -> None:
    captured: dict[str, object] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        if request.method == "GET":
            return httpx.Response(
                200,
                json={
                    "data": {
                        "simInfo": {
                            "sims": [
                                {
                                    "subscriptionId": 8,
                                    "serviceState": "OUT_OF_SERVICE",
                                    "simState": "READY",
                                    "signalLevel": 0,
                                },
                                {
                                    "subscriptionId": 7,
                                    "serviceState": "IN_SERVICE",
                                    "simState": "READY",
                                    "signalLevel": 4,
                                },
                            ]
                        }
                    }
                },
            )
        captured["body"] = json.loads(request.content.decode())
        return httpx.Response(200, json={"data": {"success": True}})

    TextbeeGateway(
        api_key="test-key",
        device_id="device-1",
        resolve_sim=True,
        transport=httpx.MockTransport(handler),
    ).send("9876543210", "code")

    assert captured["body"]["simSubscriptionId"] == 7


def test_textbee_wait_until_sent_reads_batch_status() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.method == "GET":
            assert "smsBatchId=batch-1" in str(request.url)
            return httpx.Response(
                200,
                json={"data": [{"status": "delivered", "smsBatch": "batch-1"}]},
            )
        return httpx.Response(200, json={"data": {"success": True, "smsBatchId": "batch-1"}})

    gateway = TextbeeGateway(
        api_key="test-key",
        device_id="device-1",
        transport=httpx.MockTransport(handler),
    )
    gateway.send("9876543210", "code")
    assert gateway.wait_until_sent(timeout=1.0) is True


def test_textbee_rejects_missing_sms_permission() -> None:
    from app.core.errors import SmsDeliveryError

    def handler(_request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "data": {
                    "success": True,
                    "smsBatchId": "batch-1",
                    "warning": {"code": "SMS_PERMISSION_MISSING", "message": "SMS off"},
                }
            },
        )

    gateway = TextbeeGateway(api_key="test-key", transport=httpx.MockTransport(handler))
    try:
        gateway.send("9876543210", "code")
    except SmsDeliveryError as exc:
        assert exc.status_code == 503
        assert "permission" in exc.detail.lower()
    else:
        raise AssertionError("expected SMS permission error")


def test_textbee_rejects_failed_batch() -> None:
    from app.core.errors import SmsDeliveryError

    def handler(_request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"data": {"success": False}})

    gateway = TextbeeGateway(
        api_key="test-key",
        transport=httpx.MockTransport(handler),
    )
    try:
        gateway.send("+919876543210", "code")
    except SmsDeliveryError as exc:
        assert exc.status_code == 503
        assert "123456" not in exc.detail
    else:
        raise AssertionError("expected SMS delivery error")


def test_textbee_reuses_the_resolved_sim_across_requests() -> None:
    from app.services import sms

    sms._sim_cache.clear()
    calls = {"device": 0, "send": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        if request.method == "GET":
            calls["device"] += 1
            return httpx.Response(
                200,
                json={
                    "data": {
                        "simInfo": {
                            "sims": [
                                {"subscriptionId": 7, "serviceState": "IN_SERVICE", "simState": "READY"}
                            ]
                        }
                    }
                },
            )
        calls["send"] += 1
        assert json.loads(request.content.decode())["simSubscriptionId"] == 7
        return httpx.Response(200, json={"data": {"success": True}})

    shared = httpx.Client(transport=httpx.MockTransport(handler))
    try:
        for _ in range(3):
            TextbeeGateway(
                api_key="test-key",
                device_id="device-cache",
                resolve_sim=True,
                client=shared,
            ).send("9876543210", "code")
    finally:
        shared.close()
        sms._sim_cache.clear()

    assert calls == {"device": 1, "send": 3}


def test_textbee_send_reports_transport_errors_and_a_busy_gateway() -> None:
    from app.core.errors import SmsDeliveryError

    def down(_request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("down")

    gateway = TextbeeGateway(api_key="test-key", transport=httpx.MockTransport(down))
    try:
        gateway.send("9876543210", "code")
    except SmsDeliveryError as exc:
        assert "reach" in exc.detail.lower()
    else:
        raise AssertionError("expected a transport error")

    def busy(_request: httpx.Request) -> httpx.Response:
        return httpx.Response(429, json={})

    gateway = TextbeeGateway(api_key="test-key", transport=httpx.MockTransport(busy))
    try:
        gateway.send("9876543210", "code")
    except SmsDeliveryError as exc:
        assert "busy" in exc.detail.lower()
    else:
        raise AssertionError("expected a busy gateway")


def test_textbee_wait_until_sent_covers_timeout_failure_and_http_errors() -> None:
    idle = TextbeeGateway(
        api_key="test-key",
        transport=httpx.MockTransport(lambda _request: httpx.Response(200)),
    )
    assert idle.wait_until_sent() is False

    def queued(request: httpx.Request) -> httpx.Response:
        if request.method == "POST":
            return httpx.Response(200, json={"data": {"success": True, "smsBatchId": "batch-wait"}})
        return httpx.Response(200, json={"data": [{"status": "queued"}]})

    waiting = TextbeeGateway(api_key="test-key", transport=httpx.MockTransport(queued))
    waiting.send("9876543210", "code")
    assert waiting.wait_until_sent(timeout=0) is False

    def failed(request: httpx.Request) -> httpx.Response:
        if request.method == "POST":
            return httpx.Response(200, json={"data": {"success": True, "_id": "batch-fail"}})
        return httpx.Response(200, json={"data": [{"status": "failed"}]})

    failed_gateway = TextbeeGateway(api_key="test-key", transport=httpx.MockTransport(failed))
    failed_gateway.send("9876543210", "code")
    assert failed_gateway.wait_until_sent(timeout=5) is False

    def broken(request: httpx.Request) -> httpx.Response:
        if request.method == "POST":
            return httpx.Response(200, json={"data": {"success": True, "smsBatchId": "batch-http"}})
        raise httpx.ConnectError("down")

    broken_gateway = TextbeeGateway(api_key="test-key", transport=httpx.MockTransport(broken))
    broken_gateway.send("9876543210", "code")
    assert broken_gateway.wait_until_sent(timeout=5) is False
