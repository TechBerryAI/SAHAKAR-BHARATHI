from __future__ import annotations

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import text
from sqlalchemy.engine import Engine

from app.core.security import verify_pin
from app.db.session import SessionLocal
from app.services.super_admin import (
    SUPER_ADMIN_LOGIN_ID,
    SUPER_ADMIN_MOBILE,
    LoginIdTakenError,
    seed_super_admin,
)
from tests.conftest import register_and_login


def _headers(token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}"}


def _set_role(engine: Engine, mobile: str, role: str) -> None:
    with engine.begin() as connection:
        connection.execute(
            text("UPDATE users SET role = :role WHERE mobile = :mobile"),
            {"role": role, "mobile": mobile},
        )


def test_participant_cannot_list_users_or_change_roles(client: TestClient) -> None:
    _created, session = register_and_login(client)
    headers = _headers(session["access_token"])
    listed = client.get("/api/v1/admin/users", headers=headers)
    assert listed.status_code == 403
    ghost = "00000000-0000-0000-0000-000000000001"
    opened = client.get(f"/api/v1/admin/users/{ghost}", headers=headers)
    assert opened.status_code == 403
    changed = client.post(
        f"/api/v1/admin/users/{ghost}/role",
        headers=headers,
        json={"role": "admin"},
    )
    assert changed.status_code == 403

    patched = client.patch("/api/v1/me", headers=headers, json={"role": "super_admin"})
    assert patched.status_code == 200
    assert patched.json()["role"] == "participant"


def test_admin_can_read_users_but_cannot_change_roles(client: TestClient, engine: Engine) -> None:
    first, first_session = register_and_login(client)
    _second, second_session = register_and_login(
        client,
        mobile="9123456780",
        email="second@example.com",
        full_name="Ravi Kumar",
    )
    _set_role(engine, "9123456780", "admin")
    headers = _headers(second_session["access_token"])

    listed = client.get("/api/v1/admin/users", headers=headers, params={"q": "Anita"})
    assert listed.status_code == 200
    body = listed.json()
    assert body["total"] == 1
    assert body["items"][0]["login_id"] == first["login_id"]
    assert body["items"][0]["full_name"] == "Anita Desai"
    assert "pin_hash" not in body["items"][0]

    user_id = body["items"][0]["id"]
    detail = client.get(f"/api/v1/admin/users/{user_id}", headers=headers)
    assert detail.status_code == 200
    assert detail.json()["mobile"] == "9876543210"
    assert detail.json()["district"] == "Nashik"
    assert "pin_hash" not in detail.json()

    denied = client.post(
        f"/api/v1/admin/users/{user_id}/role",
        headers=headers,
        json={"role": "admin"},
    )
    assert denied.status_code == 403
    status_denied = client.post(
        f"/api/v1/admin/users/{user_id}/status",
        headers=headers,
        json={"status": "disabled"},
    )
    assert status_denied.status_code == 403


def test_super_admin_grants_and_removes_admin_but_cannot_demote_self(client: TestClient) -> None:
    _created, _session = register_and_login(
        client,
        mobile="9123456780",
        email="ravi@example.com",
        full_name="Ravi Kumar",
    )
    db = SessionLocal()
    try:
        seeded = seed_super_admin(db, pin="1234")
        again = seed_super_admin(db, pin="1234")
        assert seeded.id == again.id
        assert seeded.login_id == SUPER_ADMIN_LOGIN_ID
        assert seeded.mobile == SUPER_ADMIN_MOBILE
        assert seeded.role == "super_admin"
        assert seeded.full_name == "Jaydeep Patil"
        assert verify_pin("1234", seeded.pin_hash)
    finally:
        db.close()

    signed_in = client.post("/api/v1/sessions", json={"identifier": SUPER_ADMIN_MOBILE, "pin": "1234"})
    assert signed_in.status_code == 200, signed_in.text
    headers = _headers(signed_in.json()["access_token"])
    assert signed_in.json()["role"] == "super_admin"

    listed = client.get("/api/v1/admin/users", headers=headers, params={"q": "9123456780"})
    assert listed.status_code == 200
    target_id = listed.json()["items"][0]["id"]

    granted = client.post(f"/api/v1/admin/users/{target_id}/role", headers=headers, json={"role": "admin"})
    assert granted.status_code == 200, granted.text
    assert granted.json()["role"] == "admin"

    removed = client.post(
        f"/api/v1/admin/users/{target_id}/role",
        headers=headers,
        json={"role": "participant"},
    )
    assert removed.status_code == 200
    assert removed.json()["role"] == "participant"

    own_id = client.get(
        "/api/v1/admin/users",
        headers=headers,
        params={"q": SUPER_ADMIN_LOGIN_ID},
    ).json()["items"][0]["id"]
    demote = client.post(f"/api/v1/admin/users/{own_id}/role", headers=headers, json={"role": "participant"})
    assert demote.status_code == 403

    db = SessionLocal()
    try:
        count = db.execute(
            text("SELECT count(*) FROM users WHERE mobile = :mobile"),
            {"mobile": SUPER_ADMIN_MOBILE},
        ).scalar_one()
        assert count == 1
        changes = db.execute(
            text("SELECT count(*) FROM audit_events WHERE event_type = 'role_change'")
        ).scalar_one()
        assert changes == 2
    finally:
        db.close()


def test_disabling_a_user_revokes_existing_sessions(client: TestClient, engine: Engine) -> None:
    created, session = register_and_login(client)
    old_token = session["access_token"]
    db = SessionLocal()
    try:
        seed_super_admin(db, pin="1234")
    finally:
        db.close()

    signed_in = client.post("/api/v1/sessions", json={"identifier": SUPER_ADMIN_MOBILE, "pin": "1234"})
    headers = _headers(signed_in.json()["access_token"])
    target_id = client.get(
        "/api/v1/admin/users",
        headers=headers,
        params={"q": created["login_id"]},
    ).json()["items"][0]["id"]

    blocked = client.post(
        f"/api/v1/admin/users/{target_id}/status",
        headers=headers,
        json={"status": "disabled"},
    )
    assert blocked.status_code == 200, blocked.text
    denied = client.get("/api/v1/me", headers=_headers(old_token))
    assert denied.status_code == 401
    with engine.connect() as connection:
        revoked = connection.execute(
            text("SELECT count(*) FROM sessions WHERE revoked_at IS NOT NULL")
        ).scalar_one()
    assert revoked >= 1

    restored = client.post(
        f"/api/v1/admin/users/{target_id}/status",
        headers=headers,
        json={"status": "active"},
    )
    assert restored.status_code == 200
    still_dead = client.get("/api/v1/me", headers=_headers(old_token))
    assert still_dead.status_code == 401
    fresh = client.post("/api/v1/sessions", json={"identifier": "9876543210", "pin": "2468"})
    assert fresh.status_code == 200, fresh.text
    assert client.get("/api/v1/me", headers=_headers(fresh.json()["access_token"])).status_code == 200


def test_super_admin_can_block_and_restore_sign_in(client: TestClient) -> None:
    created, _session = register_and_login(client)
    db = SessionLocal()
    try:
        seed_super_admin(db, pin="1234")
    finally:
        db.close()

    signed_in = client.post("/api/v1/sessions", json={"identifier": SUPER_ADMIN_MOBILE, "pin": "1234"})
    assert signed_in.status_code == 200, signed_in.text
    headers = _headers(signed_in.json()["access_token"])
    target_id = client.get(
        "/api/v1/admin/users",
        headers=headers,
        params={"q": created["login_id"]},
    ).json()["items"][0]["id"]

    blocked = client.post(f"/api/v1/admin/users/{target_id}/status", headers=headers, json={"status": "disabled"})
    assert blocked.status_code == 200, blocked.text
    assert blocked.json()["status"] == "disabled"

    rejected = client.post("/api/v1/sessions", json={"identifier": "9876543210", "pin": "2468"})
    assert rejected.status_code == 401

    own_id = client.get(
        "/api/v1/admin/users",
        headers=headers,
        params={"q": SUPER_ADMIN_LOGIN_ID},
    ).json()["items"][0]["id"]
    self_block = client.post(f"/api/v1/admin/users/{own_id}/status", headers=headers, json={"status": "disabled"})
    assert self_block.status_code == 403

    restored = client.post(f"/api/v1/admin/users/{target_id}/status", headers=headers, json={"status": "active"})
    assert restored.status_code == 200
    assert restored.json()["status"] == "active"
    allowed = client.post("/api/v1/sessions", json={"identifier": "9876543210", "pin": "2468"})
    assert allowed.status_code == 200

    unchanged = client.post(
        f"/api/v1/admin/users/{target_id}/status",
        headers=headers,
        json={"status": "active"},
    )
    assert unchanged.status_code == 200
    db = SessionLocal()
    try:
        changes = db.execute(
            text("SELECT count(*) FROM audit_events WHERE event_type = 'status_change'")
        ).scalar_one()
        assert changes == 2
    finally:
        db.close()


def test_staff_search_escapes_wildcards_and_pages(client: TestClient, engine: Engine) -> None:
    register_and_login(client, mobile="9000000001", email="one@example.com", full_name="Anita Desai")
    register_and_login(client, mobile="9000000002", email="two@example.com", full_name="Ravi Kumar")
    _set_role(engine, "9000000002", "admin")
    with engine.begin() as connection:
        connection.execute(
            text("UPDATE users SET full_name = :name WHERE mobile = :mobile"),
            {"name": "100% Done", "mobile": "9000000001"},
        )
    signed_in = client.post("/api/v1/sessions", json={"identifier": "9000000002", "pin": "2468"})
    assert signed_in.status_code == 200, signed_in.text
    headers = _headers(signed_in.json()["access_token"])

    everyone = client.get("/api/v1/admin/users", headers=headers)
    assert everyone.status_code == 200
    assert everyone.json()["total"] == 2

    percent = client.get("/api/v1/admin/users", headers=headers, params={"q": "%"})
    assert percent.status_code == 200
    assert percent.json()["total"] == 1
    assert percent.json()["items"][0]["full_name"] == "100% Done"

    underscore = client.get("/api/v1/admin/users", headers=headers, params={"q": "_"})
    assert underscore.status_code == 200
    assert underscore.json()["total"] == 0

    page = client.get("/api/v1/admin/users", headers=headers, params={"limit": 1, "offset": 1})
    assert page.status_code == 200
    assert page.json()["total"] == 2
    assert page.json()["limit"] == 1
    assert page.json()["offset"] == 1
    assert len(page.json()["items"]) == 1

    missing = client.get(
        "/api/v1/admin/users/00000000-0000-4000-8000-000000000099",
        headers=headers,
    )
    assert missing.status_code == 404
    assert missing.json()["detail"] == "That person was not found."


def test_super_admin_cannot_change_another_super_admin(client: TestClient, engine: Engine) -> None:
    created, _session = register_and_login(client)
    db = SessionLocal()
    try:
        seed_super_admin(db, pin="1234")
    finally:
        db.close()
    _set_role(engine, "9876543210", "super_admin")

    signed_in = client.post("/api/v1/sessions", json={"identifier": SUPER_ADMIN_MOBILE, "pin": "1234"})
    assert signed_in.status_code == 200, signed_in.text
    headers = _headers(signed_in.json()["access_token"])
    target_id = client.get(
        "/api/v1/admin/users",
        headers=headers,
        params={"q": created["login_id"]},
    ).json()["items"][0]["id"]

    role = client.post(f"/api/v1/admin/users/{target_id}/role", headers=headers, json={"role": "participant"})
    assert role.status_code == 403
    assert "super admin" in role.json()["detail"].lower()

    status = client.post(
        f"/api/v1/admin/users/{target_id}/status",
        headers=headers,
        json={"status": "disabled"},
    )
    assert status.status_code == 403

    missing = client.post(
        "/api/v1/admin/users/00000000-0000-4000-8000-000000000099/role",
        headers=headers,
        json={"role": "admin"},
    )
    assert missing.status_code == 404


def test_seed_rejects_a_bad_pin_and_a_taken_login_id(client: TestClient, engine: Engine) -> None:
    db = SessionLocal()
    try:
        with pytest.raises(ValueError, match="4 to 6 digits"):
            seed_super_admin(db, pin="12")
    finally:
        db.close()

    register_and_login(client, mobile="9000000003", email="holder@example.com", full_name="Other Holder")
    with engine.begin() as connection:
        connection.execute(
            text("UPDATE users SET login_id = :login_id WHERE mobile = :mobile"),
            {"login_id": SUPER_ADMIN_LOGIN_ID, "mobile": "9000000003"},
        )
    db = SessionLocal()
    try:
        with pytest.raises(LoginIdTakenError):
            seed_super_admin(db, pin="1234")
    finally:
        db.close()
