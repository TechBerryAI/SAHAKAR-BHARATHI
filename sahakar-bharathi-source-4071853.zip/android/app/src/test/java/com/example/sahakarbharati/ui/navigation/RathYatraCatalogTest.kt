package com.example.sahakarbharati.ui.navigation

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import com.example.sahakarbharati.core.copy.AppLanguage
import com.example.sahakarbharati.core.copy.copyFor

class RathYatraNavigationTest {

    @Test
    fun destinations_matchTheWebsite() {
        val ids = RathYatraDestinations.all
        assertEquals(ids.size, ids.toSet().size)
        assertTrue(ids.contains(RathYatraDestinations.SPLASH))
        assertTrue(ids.contains(RathYatraDestinations.REGISTRATION_FORM))
        assertFalse(ids.contains("welcome"))
        assertFalse(ids.contains("registration_intro"))
        assertTrue(ids.contains(RathYatraDestinations.REGISTRATION_SUCCESS))
        assertTrue(ids.contains(RathYatraDestinations.HOME))
        assertTrue(ids.contains(RathYatraDestinations.PROFILE))
        assertTrue(ids.contains(RathYatraDestinations.ADMIN))
        assertTrue(ids.contains(RathYatraDestinations.ADMIN_USER))
        assertTrue(ids.contains(RathYatraDestinations.ADMIN_PLACES))
        assertTrue(ids.contains(RathYatraDestinations.ADMIN_PLACE))
        assertTrue(ids.contains(RathYatraDestinations.ATTENDANCE))
        assertTrue(ids.contains(RathYatraDestinations.YATRAS))
        assertTrue(ids.contains(RathYatraDestinations.YATRA_DETAIL))
        assertTrue(ids.contains(RathYatraDestinations.YATRA_ATTENDANCE))
        assertTrue(ids.contains(RathYatraDestinations.YATRA_TRACKING))
        assertFalse(ids.contains("tracking"))
        assertFalse(ids.contains("qr_attendance"))
        assertFalse(ids.contains("benefits"))
        assertFalse(ids.contains("notifications"))
    }

    @Test
    fun startDestination_isSplash() {
        assertEquals(RathYatraDestinations.SPLASH, RathYatraDestinations.startDestination)
    }

    @Test
    fun navigateStack_pushesAndPopsOnboardingFlow() {
        var stack = listOf(RathYatraDestinations.SPLASH)
        stack = navigateStack(stack, RathYatraDestinations.SIGN_IN)
        stack = navigateStack(stack, RathYatraDestinations.REGISTRATION_FORM)
        assertEquals(
            listOf(
                RathYatraDestinations.SPLASH,
                RathYatraDestinations.SIGN_IN,
                RathYatraDestinations.REGISTRATION_FORM,
            ),
            stack,
        )
        stack = popStack(stack)
        assertEquals(RathYatraDestinations.SIGN_IN, stack.last())
    }

    @Test
    fun navigateStack_homeReplacesTheStackEvenWithoutReplaceRoot() {
        val stack = navigateStack(
            listOf(RathYatraDestinations.SPLASH, RathYatraDestinations.SIGN_IN),
            RathYatraDestinations.HOME,
        )
        assertEquals(listOf(RathYatraDestinations.HOME), stack)
    }

    @Test
    fun navigateStack_popsBackToADestinationAlreadyOnTheStack() {
        val stack = navigateStack(
            listOf(
                RathYatraDestinations.HOME,
                RathYatraDestinations.ADMIN,
                RathYatraDestinations.ADMIN_USER,
            ),
            RathYatraDestinations.ADMIN,
        )
        assertEquals(listOf(RathYatraDestinations.HOME, RathYatraDestinations.ADMIN), stack)
    }

    @Test
    fun popStack_keepsASingleScreen() {
        assertEquals(listOf(RathYatraDestinations.HOME), popStack(listOf(RathYatraDestinations.HOME)))
    }

    @Test
    fun navigateStack_homeReplacesRoot() {
        val stack = navigateStack(
            listOf(
                RathYatraDestinations.SPLASH,
                RathYatraDestinations.REGISTRATION_SUCCESS,
            ),
            RathYatraDestinations.HOME,
            replaceRoot = true,
        )
        assertEquals(listOf(RathYatraDestinations.HOME), stack)
    }

    @Test
    fun unknownDestination_recoversToHome() {
        val stack = navigateStack(listOf(RathYatraDestinations.HOME), "does_not_exist")
        assertEquals(listOf(RathYatraDestinations.HOME), stack)
    }

    @Test
    fun englishAndHindiCopy_honourFarmersNationwide() {
        val english = copyFor(AppLanguage.EN)
        val hindi = copyFor(AppLanguage.HI)
        assertEquals("Sahakar Bharati", english.title)
        assertEquals("Farmers & Fishermen Celebration", english.subtitle)
        assertFalse(english.portalChip.contains("demo", ignoreCase = true))
        assertFalse(english.tagline.contains("Jagannath", ignoreCase = true))
        assertFalse(english.tagline.contains("Puri", ignoreCase = true))
        assertEquals("सहकार भारती", hindi.title)
        assertTrue(hindi.subtitle.contains("किसान"))
    }
}
