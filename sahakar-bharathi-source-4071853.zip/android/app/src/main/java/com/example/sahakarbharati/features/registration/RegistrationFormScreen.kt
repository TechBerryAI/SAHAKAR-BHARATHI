package com.example.sahakarbharati.features.registration

import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.PressInteraction
import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Looper
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowForward
import androidx.compose.material.icons.outlined.AddAPhoto
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Female
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Male
import androidx.compose.material.icons.outlined.MyLocation
import androidx.compose.material.icons.outlined.PrivacyTip
import androidx.compose.material.icons.outlined.Transgender
import androidx.compose.material.icons.outlined.VerifiedUser
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SelectableDates
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.sahakarbharati.core.copy.AppLanguage
import com.example.sahakarbharati.core.copy.LocalCopy
import com.example.sahakarbharati.core.copy.LocalLanguage
import com.example.sahakarbharati.core.copy.RathYatraCopy
import com.example.sahakarbharati.core.copy.ui
import com.example.sahakarbharati.core.copy.uiKnown
import com.example.sahakarbharati.core.copy.uiText
import com.example.sahakarbharati.core.ui.ApplySystemBarIcons
import com.example.sahakarbharati.core.ui.ProfilePhoto
import com.example.sahakarbharati.core.ui.SaffronButton
import com.example.sahakarbharati.core.ui.UiState
import com.example.sahakarbharati.data.remote.RegistrationRequest
import com.example.sahakarbharati.data.rememberAppSession
import com.example.sahakarbharati.data.sahakarViewModel
import com.example.sahakarbharati.core.ui.StackTopBar
import com.example.sahakarbharati.core.ui.StatusChip
import com.example.sahakarbharati.core.ui.WhiteActionButton
import com.example.sahakarbharati.core.ui.WhiteCard
import com.example.sahakarbharati.ui.theme.FieldShape
import com.example.sahakarbharati.ui.theme.RathYatraColors
import java.util.Locale
import kotlin.coroutines.resume
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegistrationFormScreen(
    onBack: () -> Unit,
    onContinue: () -> Unit,
    onOpenSignIn: (mobile: String, accountReady: Boolean) -> Unit,
    modifier: Modifier = Modifier,
) {
    ApplySystemBarIcons(lightIcons = false)
    val copy = LocalCopy.current
    val language = LocalLanguage.current
    val extra = remember(language) { formExtraCopy(language) }
    val context = LocalContext.current
    val session = rememberAppSession()
    val accountEpoch by session.epoch
    val scope = rememberCoroutineScope()
    val viewModel: RegistrationViewModel = sahakarViewModel()

    var step by rememberSaveable(accountEpoch) { mutableStateOf(0) }
    var showSos by rememberSaveable(accountEpoch) { mutableStateOf(false) }
    var showDobPicker by rememberSaveable(accountEpoch) { mutableStateOf(false) }
    var name by rememberSaveable(accountEpoch) { mutableStateOf("") }
    var dob by rememberSaveable(accountEpoch) { mutableStateOf("") }
    var gender by rememberSaveable(accountEpoch) { mutableStateOf("") }
    var occupation by rememberSaveable(accountEpoch) { mutableStateOf("") }
    var mobile by rememberSaveable(accountEpoch) { mutableStateOf("") }
    var email by rememberSaveable(accountEpoch) { mutableStateOf("") }
    var addressLine by rememberSaveable(accountEpoch) { mutableStateOf("") }
    var locality by rememberSaveable(accountEpoch) { mutableStateOf("") }
    var district by rememberSaveable(accountEpoch) { mutableStateOf("") }
    var stateName by rememberSaveable(accountEpoch) { mutableStateOf("") }
    var pincode by rememberSaveable(accountEpoch) { mutableStateOf("") }
    var pin by remember(accountEpoch) { mutableStateOf("") }
    var confirmPin by remember(accountEpoch) { mutableStateOf("") }
    var locating by rememberSaveable(accountEpoch) { mutableStateOf(false) }
    var locationNote by rememberSaveable(accountEpoch) { mutableStateOf("") }
    var stepError by rememberSaveable(accountEpoch) { mutableStateOf("") }
    var photoPath by rememberSaveable(accountEpoch) { mutableStateOf("") }
    var otp by remember(accountEpoch) { mutableStateOf("") }

    LaunchedEffect(viewModel.state) {
        val current = viewModel.state
        if (current is UiState.Success) {
            pin = ""
            confirmPin = ""
            viewModel.consumeSuccess()
            onContinue()
        }
        if (current is UiState.Error) {
            val message = current.message
            viewModel.consumeError()
            when {
                message.contains("account was created", ignoreCase = true) -> onOpenSignIn(mobile, true)
                message.contains("Verify this mobile", ignoreCase = true) -> {
                    viewModel.clearOtp()
                    viewModel.showNote(message, error = true)
                    otp = ""
                    step = 0
                }
                message.contains("already exists for this mobile", ignoreCase = true) -> {
                    viewModel.clearOtp()
                    viewModel.showNote(message, error = true)
                    otp = ""
                    step = 0
                }
                else -> stepError = message
            }
        }
    }

    val ageYears = remember(dob) { ageYearsFromDob(dob) }
    val ageText = when {
        dob.isBlank() -> "—"
        else -> uiText(language, "ageYears", mapOf("age" to ageYears.toString()))
    }
    val formScroll = rememberScrollState()

    // A validation message describes the input it was raised for; once the participant
    // edits that input, verifies the OTP, or moves to another step it no longer applies.
    LaunchedEffect(step, mobile, viewModel.verificationToken, name, gender, dob, occupation, addressLine, locality, pin, confirmPin) {
        stepError = ""
    }
    // Each step starts at its top, so the step indicator and first field are visible.
    LaunchedEffect(step) { formScroll.scrollTo(0) }
    LaunchedEffect(viewModel.verificationToken) {
        if (step == 0 && !viewModel.verificationToken.isNullOrBlank()) step = 1
    }
    val titles = listOf(extra.contactTitle, copy.formTitle, extra.profileTitle, extra.securityTitle)
    val stepLabels = listOf(extra.contactStep, copy.stepLabel, extra.profileStep, extra.securityStep)

    fun restartFromMobile() {
        stepError = ""
        name = ""
        gender = ""
        dob = ""
        occupation = ""
        email = ""
        addressLine = ""
        locality = ""
        district = ""
        stateName = ""
        pincode = ""
        pin = ""
        confirmPin = ""
        mobile = ""
        otp = ""
        viewModel.clearOtp()
        step = 0
    }

    fun goBack() {
        stepError = ""
        val previous = previousRegistrationStep(step)
        if (previous == null) {
            restartFromMobile()
            onBack()
        } else {
            step = previous
        }
    }

    fun fillFromLocation() {
        locating = true
        locationNote = extra.locatingAddress
        scope.launch {
            val result = resolveDeviceAddress(context)
            locating = false
            locationNote = if (result.found) extra.locationFilled else extra.locationUnavailable
            result.line?.let { addressLine = it }
            result.locality?.let { locality = it }
            result.district?.let { district = it }
            result.state?.let { stateName = it }
            result.pincode?.let { pincode = it }
        }
    }

    val pickPhoto = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia(),
    ) { uri ->
        if (uri != null) {
            session.storePhoto(context, uri)?.let { photoPath = it }
        }
    }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions(),
    ) { grants ->
        if (grants.values.any { it }) {
            fillFromLocation()
        } else {
            locating = false
            locationNote = extra.locationDenied
        }
    }

    fun useCurrentLocation() {
        stepError = ""
        if (hasLocationPermission(context)) {
            fillFromLocation()
        } else {
            permissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION,
                ),
            )
        }
    }

    fun advance() {
        stepError = when (step) {
            0 -> when {
                !isIndianMobile(mobile) -> extra.mobileRequired
                viewModel.verificationToken.isNullOrBlank() -> extra.otpRequired
                else -> ""
            }
            1 -> when {
                name.trim().length < 2 -> extra.nameRequired
                gender.isBlank() -> extra.genderRequired
                isoDob(dob) == null -> extra.dobRequired
                ageYears in 0..17 -> extra.ageTooYoung
                occupation.isBlank() -> extra.occupationRequired
                district.isBlank() || stateName.isBlank() || pincode.length != 6 -> extra.addressRequired
                else -> ""
            }
            else -> when {
                pin.length < 4 -> extra.pinRequired
                pin != confirmPin -> extra.pinMismatch
                else -> ""
            }
        }
        if (stepError.isNotEmpty()) return
        if (step < REGISTRATION_LAST_STEP) {
            step += 1
        } else if (viewModel.state !is UiState.Loading) {
            viewModel.submit(
                RegistrationRequest(
                    fullName = name.trim(),
                    gender = gender.ifBlank { null },
                    dateOfBirth = isoDob(dob),
                    occupation = occupation.ifBlank { null },
                    mobile = mobile,
                    email = email.ifBlank { null },
                    addressLine = addressLine.ifBlank { null },
                    locality = locality.ifBlank { null },
                    district = district.ifBlank { null },
                    state = stateName.ifBlank { null },
                    pincode = pincode.ifBlank { null },
                    pin = pin,
                    verificationToken = viewModel.verificationToken.orEmpty(),
                ),
            )
        }
    }

    BackHandler(onBack = { goBack() })

    if (step == 0) {
        VerifyMobileScreen(
            mobile = mobile,
            onMobile = {
                val next = it.filter(Char::isDigit).take(10)
                if (next != mobile) {
                    otp = ""
                    viewModel.clearOtp()
                }
                mobile = next
            },
            otp = otp,
            onOtp = { otp = it.filter(Char::isDigit).take(6) },
            otpSent = viewModel.otpSent,
            otpBusy = viewModel.otpBusy,
            note = when {
                viewModel.otpNoteKey != null -> ui(viewModel.otpNoteKey!!)
                viewModel.otpNote.isNotBlank() -> uiKnown(viewModel.otpNote)
                else -> stepError
            },
            noteIsError = viewModel.otpIsError || (viewModel.otpNote.isBlank() && viewModel.otpNoteKey == null && stepError.isNotBlank()),
            accountExists = viewModel.accountExists ||
                viewModel.otpNote.contains("already exists for this mobile", ignoreCase = true),
            onBack = { goBack() },
            onSignIn = { onOpenSignIn(mobile, false) },
            onResend = { viewModel.sendOtp(mobile) },
            verified = !viewModel.verificationToken.isNullOrBlank(),
            onSubmit = {
                when {
                    !isIndianMobile(mobile) -> stepError = extra.mobileRequired
                    !viewModel.verificationToken.isNullOrBlank() -> step = 1
                    !viewModel.otpSent -> viewModel.sendOtp(mobile)
                    else -> viewModel.confirmOtp(otp)
                }
            },
            modifier = modifier,
        )
    } else RegistrationDetailsScreen(
        step = step,
        name = name,
        onName = { name = it },
        gender = gender,
        onGender = { gender = it },
        dob = dob,
        onDob = { dob = it },
        occupation = occupation,
        onOccupation = { occupation = it },
        mobile = mobile,
        email = email,
        onEmail = { email = it },
        addressLine = addressLine,
        onAddressLine = { addressLine = it },
        locality = locality,
        onLocality = { locality = it },
        district = district,
        onDistrict = { district = it },
        stateName = stateName,
        onState = { stateName = it },
        pincode = pincode,
        onPincode = { pincode = it.filter(Char::isDigit).take(6) },
        pin = pin,
        onPin = { pin = it.filter(Char::isDigit).take(6) },
        confirmPin = confirmPin,
        onConfirmPin = { confirmPin = it.filter(Char::isDigit).take(6) },
        error = stepError,
        loading = viewModel.state is UiState.Loading,
        onBack = { goBack() },
        onSos = { showSos = true },
        onCreate = { advance() },
        modifier = modifier,
    )
    if (showSos) {
        com.example.sahakarbharati.core.ui.DemoAlertDialog(
            title = copy.sosTitle,
            body = copy.sosBody,
            onDismiss = { showSos = false },
        )
    }
    if (showDobPicker) {
        BirthdayPickerDialog(
            initialDob = dob,
            confirmLabel = if (language == AppLanguage.HI) "ठीक है" else "OK",
            dismissLabel = if (language == AppLanguage.HI) "रद्द करें" else "Cancel",
            onConfirm = { millis ->
                dob = formatDob(millis)
                showDobPicker = false
            },
            onDismiss = { showDobPicker = false },
        )
    }
}

@Composable
private fun ColumnScope.PersonalStep(
    copy: RathYatraCopy,
    extra: FormExtraCopy,
    name: String,
    onName: (String) -> Unit,
    photoPath: String,
    onPickPhoto: () -> Unit,
    gender: String,
    onGender: (String) -> Unit,
    dob: String,
    onOpenDob: () -> Unit,
    ageText: String,
    ageYears: Int,
    occupation: String,
    onOccupation: (String) -> Unit,
    email: String,
    onEmail: (String) -> Unit,
) {
    WhiteCard {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(copy.formCardTitle, style = MaterialTheme.typography.titleSmall, color = RathYatraColors.Navy)
            Text(copy.formCardBody, style = MaterialTheme.typography.bodySmall, color = RathYatraColors.OnSurfaceVariant)
        }
    }
    WhiteCard {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(extra.photoTitle, style = MaterialTheme.typography.labelSmall, color = RathYatraColors.OnSurfaceVariant)
            ProfilePhoto(
                photoPath = photoPath,
                initials = name.split(" ").filter { it.isNotBlank() }.take(2)
                    .joinToString("") { it.first().uppercase() }
                    .ifBlank { "SB" },
                size = 88.dp,
                onClick = onPickPhoto,
            )
            Text(
                extra.photoHint,
                style = MaterialTheme.typography.bodySmall,
                color = RathYatraColors.OnSurfaceVariant,
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.clickable(onClick = onPickPhoto),
            ) {
                Icon(
                    Icons.Outlined.AddAPhoto,
                    contentDescription = extra.photoGallery,
                    tint = RathYatraColors.Navy,
                    modifier = Modifier.size(18.dp),
                )
                Text(
                    extra.photoGallery,
                    style = MaterialTheme.typography.bodySmall,
                    color = RathYatraColors.Navy,
                    fontWeight = FontWeight.Medium,
                )
            }
        }
    }
    WhiteCard {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(copy.legalName, style = MaterialTheme.typography.labelSmall, color = RathYatraColors.OnSurfaceVariant)
                StatusChip(copy.asInId, container = RathYatraColors.SurfaceContainerLow, content = RathYatraColors.Navy)
            }
            OutlinedTextField(
                value = name,
                onValueChange = onName,
                modifier = Modifier.fillMaxWidth(),
                shape = FieldShape,
                trailingIcon = if (name.trim().length >= 2) {
                    { Icon(Icons.Outlined.Check, contentDescription = null, tint = RathYatraColors.Navy) }
                } else {
                    null
                },
                colors = fieldColors(),
            )
            Text(copy.nameHint, style = MaterialTheme.typography.bodySmall, color = RathYatraColors.OnSurfaceVariant)
        }
    }
    WhiteCard {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(copy.gender, style = MaterialTheme.typography.labelSmall)
                StatusChip(copy.mandatory, container = RathYatraColors.PrimaryFixed, content = RathYatraColors.BurntSaffron)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GenderChip(copy.male, Icons.Outlined.Male, gender == "Male", Modifier.weight(1f)) { onGender("Male") }
                GenderChip(copy.female, Icons.Outlined.Female, gender == "Female", Modifier.weight(1f)) { onGender("Female") }
                GenderChip(copy.other, Icons.Outlined.Transgender, gender == "Other", Modifier.weight(1f)) { onGender("Other") }
            }
        }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        WhiteCard(Modifier.weight(1.2f)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(copy.dob, style = MaterialTheme.typography.labelSmall)
                // Read-only field: tapping anywhere on it opens the picker, not only the icon.
                val dobInteraction = remember { MutableInteractionSource() }
                LaunchedEffect(dobInteraction) {
                    dobInteraction.interactions.collect { if (it is PressInteraction.Release) onOpenDob() }
                }
                OutlinedTextField(
                    value = dob,
                    onValueChange = {},
                    readOnly = true,
                    interactionSource = dobInteraction,
                    modifier = Modifier.fillMaxWidth(),
                    shape = FieldShape,
                    trailingIcon = {
                        Icon(Icons.Outlined.CalendarMonth, contentDescription = ui("dateOfBirth"))
                    },
                    colors = fieldColors(),
                )
                Text(copy.ageMin, style = MaterialTheme.typography.bodySmall, color = RathYatraColors.OnSurfaceVariant)
            }
        }
        WhiteCard(Modifier.weight(0.9f)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(copy.calculatedAge, style = MaterialTheme.typography.labelSmall, modifier = Modifier.weight(1f))
                    Icon(Icons.Outlined.Info, null, Modifier.size(14.dp), RathYatraColors.GoldDark)
                }
                StatusChip(ageText, container = RathYatraColors.GoldPale, content = RathYatraColors.GoldDark)
                if (ageYears >= 18) {
                    Text(copy.eligible, style = MaterialTheme.typography.labelSmall, color = RathYatraColors.Success)
                    Text(copy.eligibleNote, style = MaterialTheme.typography.bodySmall, color = RathYatraColors.OnSurfaceVariant)
                }
            }
        }
    }
    WhiteCard {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(copy.occupation, style = MaterialTheme.typography.labelSmall)
            Text(copy.occupationHint, style = MaterialTheme.typography.bodySmall, color = RathYatraColors.OnSurfaceVariant)
            val occupations = listOf(
                Triple("Farmer", copy.farmer, copy.farmerDesc),
                Triple("Fisherman", copy.fisherman, copy.fishermanDesc),
                Triple("Both", copy.both, copy.bothDesc),
                Triple("Allied", copy.allied, copy.alliedDesc),
            )
            occupations.chunked(2).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { (key, title, body) ->
                        val selected = occupation == key
                        Column(
                            Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .border(
                                    width = if (selected) 2.dp else 1.dp,
                                    color = if (selected) RathYatraColors.Saffron else RathYatraColors.SurfaceContainerHighest,
                                    shape = RoundedCornerShape(12.dp),
                                )
                                .clickable { onOccupation(key) }
                                .padding(12.dp),
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (selected) {
                                    Box(Modifier.size(8.dp).background(RathYatraColors.Saffron, CircleShape))
                                    Spacer(Modifier.size(6.dp))
                                }
                                Text(title, style = MaterialTheme.typography.titleSmall)
                            }
                            Text(body, style = MaterialTheme.typography.bodySmall, color = RathYatraColors.OnSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
    LabeledField(
        label = extra.emailLabel,
        value = email,
        onValueChange = onEmail,
        hint = extra.emailHint,
        keyboardType = KeyboardType.Email,
    )
}

@Composable
private fun VerifyMobileScreen(
    mobile: String,
    onMobile: (String) -> Unit,
    otp: String,
    onOtp: (String) -> Unit,
    otpSent: Boolean,
    otpBusy: Boolean,
    note: String,
    noteIsError: Boolean,
    accountExists: Boolean,
    verified: Boolean = false,
    onBack: () -> Unit,
    onSignIn: () -> Unit,
    onResend: () -> Unit,
    onSubmit: () -> Unit,
    modifier: Modifier = Modifier,
) {
    ApplySystemBarIcons(lightIcons = false)
    Column(
        modifier
            .fillMaxSize()
            .background(androidx.compose.ui.graphics.Color(0xFFFFF8EF))
            .windowInsetsPadding(WindowInsets.statusBars)
            .windowInsetsPadding(WindowInsets.navigationBars)
            .windowInsetsPadding(WindowInsets.ime),
    ) {
        StackTopBar(title = ui("verifyMobile"), onBack = onBack)
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            WhiteCard {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        ui("mobileLabel"),
                        style = MaterialTheme.typography.labelMedium.copy(letterSpacing = 0.4.sp),
                        color = Color(0xFF0F3D2E),
                        fontWeight = FontWeight.Medium,
                    )
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .border(1.dp, RathYatraColors.Gold, RoundedCornerShape(12.dp))
                            .background(RathYatraColors.White)
                            .padding(horizontal = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Text("+91", color = RathYatraColors.OnSurfaceVariant)
                        BasicTextField(
                            value = mobile,
                            onValueChange = onMobile,
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            textStyle = MaterialTheme.typography.bodyLarge.copy(color = RathYatraColors.OnSurface),
                            modifier = Modifier.weight(1f),
                        )
                    }
                    Text(
                        ui("mobileHint"),
                        style = MaterialTheme.typography.bodySmall,
                        color = RathYatraColors.OnSurfaceVariant,
                    )
                    if (otpSent) {
                        Spacer(Modifier.height(8.dp))
                        Text(
                            ui("otpLabel"),
                            style = MaterialTheme.typography.labelLarge,
                            color = RathYatraColors.OnSurfaceVariant,
                        )
                        OutlinedTextField(
                            value = otp,
                            onValueChange = onOtp,
                            modifier = Modifier.fillMaxWidth(),
                            shape = FieldShape,
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = fieldColors(),
                        )
                        Text(
                            ui("otpSmsHint"),
                            style = MaterialTheme.typography.bodySmall,
                            color = RathYatraColors.OnSurfaceVariant,
                        )
                        TextButton(onClick = { if (!otpBusy) onResend() }, enabled = !otpBusy) {
                            Text(ui("resendOtp"), color = RathYatraColors.Navy)
                        }
                    }
                }
            }
            if (note.isNotBlank()) {
                Text(
                    uiKnown(note),
                    style = MaterialTheme.typography.bodySmall,
                    color = if (noteIsError) RathYatraColors.Emergency else RathYatraColors.OnSurfaceVariant,
                )
            }
            if (accountExists || otpSent) {
                SaffronButton(
                    text = ui("signIn"),
                    onClick = onSignIn,
                    trailingIcon = Icons.AutoMirrored.Outlined.ArrowForward,
                )
            }
        }
        Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
            SaffronButton(
                text = when {
                    otpBusy -> ui("pleaseWait")
                    verified -> ui("continue")
                    otpSent -> ui("verifyOtp")
                    else -> ui("sendOtp")
                },
                onClick = { if (!otpBusy) onSubmit() },
                trailingIcon = Icons.AutoMirrored.Outlined.ArrowForward,
            )
        }
    }
}

@Composable
private fun ColumnScope.PhoneStep(
    extra: FormExtraCopy,
    mobile: String,
    onMobile: (String) -> Unit,
    otp: String,
    onOtp: (String) -> Unit,
    otpNote: String,
    otpVerified: Boolean,
    otpBusy: Boolean,
    onSendOtp: () -> Unit,
    onConfirmOtp: () -> Unit,
) {
    WhiteCard {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(extra.contactCard, style = MaterialTheme.typography.titleSmall, color = RathYatraColors.Navy)
            Text(extra.contactBody, style = MaterialTheme.typography.bodySmall, color = RathYatraColors.OnSurfaceVariant)
        }
    }
    LabeledField(
        label = extra.mobileLabel,
        value = mobile,
        onValueChange = onMobile,
        hint = extra.mobileHint,
        keyboardType = KeyboardType.Phone,
        prefix = "+91",
    )
    WhiteActionButton(
        text = when {
            otpBusy && !otpVerified -> extra.sendingOtp
            otpVerified -> extra.otpVerified
            else -> extra.sendOtp
        },
        onClick = { if (!otpBusy && !otpVerified) onSendOtp() },
        filled = !otpVerified,
    )
    if (!otpVerified) {
        LabeledField(
            label = extra.otpLabel,
            value = otp,
            onValueChange = onOtp,
            hint = extra.otpHint,
            keyboardType = KeyboardType.Number,
        )
        WhiteActionButton(
            text = extra.verifyOtp,
            onClick = { if (!otpBusy) onConfirmOtp() },
        )
    }
    if (otpNote.isNotBlank()) {
        Text(otpNote, style = MaterialTheme.typography.bodySmall, color = RathYatraColors.Navy)
    }
}

@Composable
private fun ColumnScope.AddressStep(
    extra: FormExtraCopy,
    addressLine: String,
    onAddressLine: (String) -> Unit,
    locality: String,
    onLocality: (String) -> Unit,
    district: String,
    onDistrict: (String) -> Unit,
    stateName: String,
    onState: (String) -> Unit,
    pincode: String,
    onPincode: (String) -> Unit,
    locating: Boolean,
    locationNote: String,
    onUseLocation: () -> Unit,
) {
    WhiteCard {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(extra.profileCard, style = MaterialTheme.typography.titleSmall, color = RathYatraColors.Navy)
            Text(extra.profileBody, style = MaterialTheme.typography.bodySmall, color = RathYatraColors.OnSurfaceVariant)
        }
    }
    WhiteCard {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(extra.addressLabel, style = MaterialTheme.typography.labelSmall, color = RathYatraColors.OnSurfaceVariant)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(RathYatraColors.SecondaryPale)
                    .clickable(enabled = !locating, onClick = onUseLocation)
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                if (locating) {
                    CircularProgressIndicator(Modifier.size(18.dp), color = RathYatraColors.Navy, strokeWidth = 2.dp)
                } else {
                    Icon(Icons.Outlined.MyLocation, contentDescription = extra.useMyLocation, tint = RathYatraColors.Navy)
                }
                Column(Modifier.weight(1f)) {
                    Text(extra.useMyLocation, style = MaterialTheme.typography.titleSmall, color = RathYatraColors.Navy)
                    Text(extra.useMyLocationHint, style = MaterialTheme.typography.bodySmall, color = RathYatraColors.OnSurfaceVariant)
                }
            }
            if (locationNote.isNotEmpty()) {
                Text(locationNote, style = MaterialTheme.typography.bodySmall, color = RathYatraColors.Navy)
            }
        }
    }
    LabeledField(extra.houseLabel, addressLine, onAddressLine, extra.houseHint)
    LabeledField(extra.localityLabel, locality, onLocality)
    LabeledField(extra.districtLabel, district, onDistrict)
    LabeledField(extra.stateLabel, stateName, onState)
    LabeledField(extra.pincodeLabel, pincode, onPincode, keyboardType = KeyboardType.Number)
}

@Composable
private fun ColumnScope.SecurityStep(
    extra: FormExtraCopy,
    pin: String,
    onPin: (String) -> Unit,
    confirmPin: String,
    onConfirmPin: (String) -> Unit,
) {
    WhiteCard {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(extra.securityCard, style = MaterialTheme.typography.titleSmall, color = RathYatraColors.Navy)
            Text(extra.securityBody, style = MaterialTheme.typography.bodySmall, color = RathYatraColors.OnSurfaceVariant)
        }
    }
    LabeledField(
        label = extra.pinLabel,
        value = pin,
        onValueChange = onPin,
        hint = extra.pinHint,
        keyboardType = KeyboardType.NumberPassword,
        password = true,
    )
    LabeledField(
        label = extra.confirmPinLabel,
        value = confirmPin,
        onValueChange = onConfirmPin,
        keyboardType = KeyboardType.NumberPassword,
        password = true,
    )
}

@Composable
private fun LabeledField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    hint: String? = null,
    keyboardType: KeyboardType = KeyboardType.Text,
    prefix: String? = null,
    password: Boolean = false,
) {
    WhiteCard {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = RathYatraColors.OnSurfaceVariant)
            OutlinedTextField(
                value = value,
                onValueChange = onValueChange,
                modifier = Modifier.fillMaxWidth(),
                shape = FieldShape,
                colors = fieldColors(),
                keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
                visualTransformation = if (password) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
                prefix = prefix?.let { { Text(it, color = RathYatraColors.OnSurfaceVariant) } },
                singleLine = true,
            )
            if (hint != null) {
                Text(hint, style = MaterialTheme.typography.bodySmall, color = RathYatraColors.OnSurfaceVariant)
            }
        }
    }
}

@Composable
private fun GenderChip(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) RathYatraColors.Navy else RathYatraColors.SurfaceContainerLow)
            .clickable(onClick = onClick)
            .semantics(mergeDescendants = true) {}
            .padding(horizontal = 8.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
    ) {
        Icon(icon, contentDescription = null, tint = if (selected) Color.White else RathYatraColors.Navy, modifier = Modifier.size(16.dp))
        Text(" $label", style = MaterialTheme.typography.labelSmall, color = if (selected) Color.White else RathYatraColors.Navy, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = RathYatraColors.Saffron,
    unfocusedBorderColor = RathYatraColors.Gold,
    focusedContainerColor = RathYatraColors.White,
    unfocusedContainerColor = RathYatraColors.White,
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun BirthdayPickerDialog(
    initialDob: String,
    confirmLabel: String,
    dismissLabel: String,
    onConfirm: (Long) -> Unit,
    onDismiss: () -> Unit,
) {
    val today = remember { System.currentTimeMillis() }
    val currentYear = remember {
        java.util.Calendar.getInstance().get(java.util.Calendar.YEAR)
    }
    val initialSelected = parseDobToUtcMillis(initialDob)
    val datePickerState = rememberDatePickerState(
        initialSelectedDateMillis = initialSelected,
        // Participants are adults: open on a plausible birth year instead of this month.
        initialDisplayedMonthMillis = initialSelected ?: remember {
            java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC")).apply {
                add(java.util.Calendar.YEAR, -25)
            }.timeInMillis
        },
        yearRange = IntRange(currentYear - 120, currentYear),
        selectableDates = object : SelectableDates {
            override fun isSelectableDate(utcTimeMillis: Long): Boolean = utcTimeMillis <= today
        },
    )
    DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = { datePickerState.selectedDateMillis?.let(onConfirm) }) {
                Text(confirmLabel, color = RathYatraColors.Navy)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(dismissLabel, color = RathYatraColors.OnSurfaceVariant)
            }
        },
    ) {
        DatePicker(state = datePickerState)
    }
}

private data class FormExtraCopy(
    val contactTitle: String,
    val contactStep: String,
    val contactCard: String,
    val contactBody: String,
    val mobileLabel: String,
    val mobileHint: String,
    val emailLabel: String,
    val emailHint: String,
    val profileTitle: String,
    val profileStep: String,
    val profileCard: String,
    val profileBody: String,
    val addressLabel: String,
    val houseLabel: String,
    val houseHint: String,
    val localityLabel: String,
    val districtLabel: String,
    val stateLabel: String,
    val pincodeLabel: String,
    val useMyLocation: String,
    val useMyLocationHint: String,
    val locatingAddress: String,
    val locationFilled: String,
    val locationDenied: String,
    val locationUnavailable: String,
    val securityTitle: String,
    val securityStep: String,
    val securityCard: String,
    val securityBody: String,
    val pinLabel: String,
    val pinHint: String,
    val confirmPinLabel: String,
    val photoTitle: String,
    val photoHint: String,
    val photoReady: String,
    val photoRequired: String,
    val photoGallery: String,
    val nameRequired: String,
    val genderRequired: String,
    val dobRequired: String,
    val occupationRequired: String,
    val ageTooYoung: String,
    val mobileRequired: String,
    val sendOtp: String,
    val sendingOtp: String,
    val otpLabel: String,
    val otpHint: String,
    val verifyOtp: String,
    val otpVerified: String,
    val otpRequired: String,
    val addressRequired: String,
    val pinRequired: String,
    val pinMismatch: String,
)

private fun formExtraCopy(language: AppLanguage): FormExtraCopy {
    fun s(key: String) = uiText(language, key)
    return FormExtraCopy(
        contactTitle = s("mobileLabel"),
        contactStep = s("contactStep"),
        contactCard = s("contactCard"),
        contactBody = s("contactBody"),
        mobileLabel = s("mobileLabel"),
        mobileHint = s("mobileHint"),
        emailLabel = s("emailOptional"),
        emailHint = s("contactEmailHint"),
        profileTitle = s("profileTitle"),
        profileStep = s("profileStep"),
        profileCard = s("profileTitle"),
        profileBody = s("addressCardBody"),
        addressLabel = s("address"),
        houseLabel = s("houseLabel"),
        houseHint = s("houseHint"),
        localityLabel = s("localityLabel"),
        districtLabel = s("districtLabel"),
        stateLabel = s("stateLabel"),
        pincodeLabel = s("pincodeLabel"),
        useMyLocation = s("useMyLocation"),
        useMyLocationHint = s("useMyLocationHint"),
        locatingAddress = s("locatingAddress"),
        locationFilled = s("locationFilled"),
        locationDenied = s("locationDenied"),
        locationUnavailable = s("locationUnavailable"),
        securityTitle = s("securityTitle"),
        securityStep = s("securityStep"),
        securityCard = s("securityCardTitle"),
        securityBody = s("securityCardBody"),
        pinLabel = s("securityPinLabel"),
        pinHint = s("securityPinHint"),
        confirmPinLabel = s("securityConfirmPin"),
        photoTitle = s("photoTitle"),
        photoHint = s("photoHint"),
        photoReady = s("photoReady"),
        photoRequired = s("photoRequired"),
        photoGallery = s("photoGallery"),
        nameRequired = s("fullNameRequired"),
        genderRequired = s("genderRequired"),
        dobRequired = s("dobRequired"),
        occupationRequired = s("occupationRequired"),
        ageTooYoung = s("minAge"),
        mobileRequired = s("mobileRequired"),
        sendOtp = s("sendOtp"),
        sendingOtp = s("sendingOtp"),
        otpLabel = s("otpLabel"),
        otpHint = s("otpSmsHint"),
        verifyOtp = s("verifyOtp"),
        otpVerified = s("otpVerified"),
        otpRequired = s("otpVerifyRequired"),
        addressRequired = s("addressRequired"),
        pinRequired = s("passwordLength"),
        pinMismatch = s("passwordMatch"),
    )
}

private data class AddressResult(
    val line: String? = null,
    val locality: String? = null,
    val district: String? = null,
    val state: String? = null,
    val pincode: String? = null,
    val found: Boolean = false,
)

private fun hasLocationPermission(context: Context): Boolean {
    val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION)
    val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION)
    return fine == PackageManager.PERMISSION_GRANTED || coarse == PackageManager.PERMISSION_GRANTED
}

private suspend fun resolveDeviceAddress(context: Context): AddressResult {
    val location = withTimeoutOrNull(12_000) { awaitLocation(context) }
        ?: return AddressResult()
    val address = geocodeLocation(context, location)
    if (address == null) {
        return AddressResult(
            line = "Lat %.5f, Lon %.5f".format(location.latitude, location.longitude),
        )
    }
    val line = address.getAddressLine(0)
        ?: listOfNotNull(address.featureName, address.thoroughfare, address.subLocality)
            .joinToString(", ")
            .ifBlank { null }
    val locality = address.subLocality ?: address.locality
    return AddressResult(
        line = line,
        locality = locality,
        district = address.subAdminArea ?: address.locality,
        state = address.adminArea,
        pincode = address.postalCode,
        found = true,
    )
}

private suspend fun awaitLocation(context: Context): Location? {
    if (!hasLocationPermission(context)) return null
    val manager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    val last = listOf(
        LocationManager.GPS_PROVIDER,
        LocationManager.NETWORK_PROVIDER,
        LocationManager.PASSIVE_PROVIDER,
    ).mapNotNull { provider ->
        // Permission was checked above, but it can be revoked at any moment.
        try {
            manager.getLastKnownLocation(provider)
        } catch (_: SecurityException) {
            null
        } catch (_: IllegalArgumentException) {
            null // provider not present on this device
        }
    }.maxByOrNull { it.time }
    val freshEnough = last != null && System.currentTimeMillis() - last.time < 10 * 60 * 1000
    if (freshEnough) return last
    val provider = when {
        manager.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
        manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
        else -> return last
    }
    return suspendCancellableCoroutine { cont ->
        val listener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                runCatching { manager.removeUpdates(this) }
                if (cont.isActive) cont.resume(location)
            }
        }
        try {
            manager.requestLocationUpdates(provider, 0L, 0f, listener, Looper.getMainLooper())
            cont.invokeOnCancellation { runCatching { manager.removeUpdates(listener) } }
        } catch (_: SecurityException) {
            if (cont.isActive) cont.resume(last)
        }
    }
}

private suspend fun geocodeLocation(context: Context, location: Location): android.location.Address? {
    if (!Geocoder.isPresent()) return null
    val geocoder = Geocoder(context, Locale("en", "IN"))
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        suspendCancellableCoroutine { cont ->
            geocoder.getFromLocation(location.latitude, location.longitude, 1) { list ->
                if (cont.isActive) cont.resume(list.firstOrNull())
            }
        }
    } else {
        withContext(Dispatchers.IO) {
            @Suppress("DEPRECATION")
            geocoder.getFromLocation(location.latitude, location.longitude, 1)?.firstOrNull()
        }
    }
}
