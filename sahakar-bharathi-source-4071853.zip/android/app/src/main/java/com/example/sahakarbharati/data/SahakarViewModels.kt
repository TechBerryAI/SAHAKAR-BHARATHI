package com.example.sahakarbharati.data

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import com.example.sahakarbharati.SahakarApp
import com.example.sahakarbharati.features.admin.AdminPlaceViewModel
import com.example.sahakarbharati.features.admin.AdminPlacesViewModel
import com.example.sahakarbharati.features.admin.AdminUserViewModel
import com.example.sahakarbharati.features.attendance.AttendanceViewModel
import com.example.sahakarbharati.features.admin.AdminUsersViewModel
import com.example.sahakarbharati.features.home.HomeViewModel
import com.example.sahakarbharati.features.profile.ProfileViewModel
import com.example.sahakarbharati.features.registration.RegistrationViewModel
import com.example.sahakarbharati.features.registration.SignInViewModel
import com.example.sahakarbharati.features.yatra.YatraAttendanceViewModel
import com.example.sahakarbharati.features.yatra.YatraDetailViewModel
import com.example.sahakarbharati.features.yatra.YatraListViewModel
import com.example.sahakarbharati.features.yatra.YatraTrackingViewModel

class SahakarViewModelFactory(
    private val container: AppContainer,
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(RegistrationViewModel::class.java) ->
                RegistrationViewModel(container.authRepository, container.session) as T
            modelClass.isAssignableFrom(SignInViewModel::class.java) ->
                SignInViewModel(container.authRepository, container.session) as T
            modelClass.isAssignableFrom(ProfileViewModel::class.java) ->
                ProfileViewModel(container.profileRepository, container.authRepository, container.session) as T
            modelClass.isAssignableFrom(HomeViewModel::class.java) ->
                HomeViewModel(container.profileRepository, container.session) as T
            modelClass.isAssignableFrom(AdminUsersViewModel::class.java) ->
                AdminUsersViewModel(container.adminRepository, container.session) as T
            modelClass.isAssignableFrom(AdminUserViewModel::class.java) ->
                AdminUserViewModel(container.adminRepository, container.session) as T
            modelClass.isAssignableFrom(AdminPlacesViewModel::class.java) ->
                AdminPlacesViewModel(container.adminRepository, container.session) as T
            modelClass.isAssignableFrom(AdminPlaceViewModel::class.java) ->
                AdminPlaceViewModel(container.adminRepository, container.session) as T
            modelClass.isAssignableFrom(AttendanceViewModel::class.java) ->
                AttendanceViewModel(container.attendanceRepository, container.session) as T
            modelClass.isAssignableFrom(YatraListViewModel::class.java) ->
                YatraListViewModel(container.yatraRepository) as T
            modelClass.isAssignableFrom(YatraDetailViewModel::class.java) ->
                YatraDetailViewModel(container.yatraRepository) as T
            modelClass.isAssignableFrom(YatraAttendanceViewModel::class.java) ->
                YatraAttendanceViewModel(container.yatraFieldRepository) as T
            modelClass.isAssignableFrom(YatraTrackingViewModel::class.java) ->
                YatraTrackingViewModel(
                    container.yatraFieldRepository,
                    container.session,
                    container.positionQueue,
                ) as T
            else -> error("Unknown ViewModel ${modelClass.name}")
        }
    }
}

@Composable
fun rememberViewModelFactory(): SahakarViewModelFactory {
    val context = LocalContext.current
    val container = (context.applicationContext as SahakarApp).container
    return SahakarViewModelFactory(container)
}

@Composable
inline fun <reified VM : ViewModel> sahakarViewModel(): VM {
    return viewModel(factory = rememberViewModelFactory())
}

fun Context.appContainer(): AppContainer = (applicationContext as SahakarApp).container
