import { Navigate, Route, Routes, useLocation } from 'react-router-dom'
import type { ReactNode } from 'react'
import { AppShell } from './components/AppShell.tsx'
import { Button, Card, Screen } from './components/ui.tsx'
import { useLanguage } from './contexts/language.tsx'
import { useSession } from './hooks/useSession.ts'
import { isStaffRole, logout, restoreSession } from './lib/api.ts'
import { AdminPlaceScreen } from './screens/AdminPlaceScreen.tsx'
import { AdminPlacesScreen } from './screens/AdminPlacesScreen.tsx'
import { AdminUserScreen } from './screens/AdminUserScreen.tsx'
import { AdminUsersScreen } from './screens/AdminUsersScreen.tsx'
import { CheckInScreen } from './screens/CheckInScreen.tsx'
import { DistrictsScreen } from './screens/DistrictsScreen.tsx'
import { HomeScreen } from './screens/HomeScreen.tsx'
import { ProfileScreen } from './screens/ProfileScreen.tsx'
import { RegisterScreen } from './screens/RegisterScreen.tsx'
import { RegisterSuccessScreen } from './screens/RegisterSuccessScreen.tsx'
import { SignInScreen } from './screens/SignInScreen.tsx'
import { StartScreen } from './screens/StartScreen.tsx'
import { YatraAttendanceScreen } from './screens/YatraAttendanceScreen.tsx'
import { YatraScreen } from './screens/YatraScreen.tsx'
import { YatrasScreen } from './screens/YatrasScreen.tsx'

function GuestRoute({ children }: { children: ReactNode }) {
  const { uid } = useSession()
  if (uid) return <Navigate to="/" replace />
  return children
}

function ProtectedRoute({ children }: { children: ReactNode }) {
  const { uid } = useSession()
  if (!uid) return <Navigate to="/" replace />
  return children
}

function AdminRoute({ children }: { children: ReactNode }) {
  const { uid, profile } = useSession()
  if (!uid) return <Navigate to="/" replace />
  if (!isStaffRole(profile?.role)) return <Navigate to="/" replace />
  return children
}

function HomeOrStart() {
  const { uid } = useSession()
  if (!uid) return <StartScreen />
  return <HomeScreen />
}

function RestoreFailed() {
  const { copy } = useLanguage()
  return (
    <Screen>
      <Card title={copy.networkError}>
        <div className="stack">
          <Button type="button" onClick={() => void restoreSession()}>
            {copy.goHome}
          </Button>
          <Button type="button" variant="ghost" onClick={() => void logout()}>
            {copy.logOut}
          </Button>
        </div>
      </Card>
    </Screen>
  )
}

function AppRoutes() {
  const location = useLocation()
  const { ready, restoreFailed } = useSession()
  const { copy } = useLanguage()

  if (!ready) {
    return (
      <div className="center-state">
        <div className="spinner" aria-label={copy.pleaseWait} />
      </div>
    )
  }

  // A saved session could not be checked (offline or server down). Showing the
  // signed-out start screen here would look like an unexplained logout.
  if (restoreFailed) {
    return <RestoreFailed />
  }

  return (
    <div className="screen-slot" key={location.pathname}>
      <Routes location={location}>
        <Route
          path="/sign-in"
          element={
            <GuestRoute>
              <SignInScreen />
            </GuestRoute>
          }
        />
        <Route path="/register" element={<RegisterScreen />} />
        <Route
          path="/register/success"
          element={
            <ProtectedRoute>
              <RegisterSuccessScreen />
            </ProtectedRoute>
          }
        />
        <Route path="/" element={<HomeOrStart />} />
        <Route
          path="/check-in"
          element={
            <ProtectedRoute>
              <CheckInScreen />
            </ProtectedRoute>
          }
        />
        <Route
          path="/profile"
          element={
            <ProtectedRoute>
              <ProfileScreen />
            </ProtectedRoute>
          }
        />
        <Route
          path="/admin"
          element={
            <AdminRoute>
              <AdminUsersScreen />
            </AdminRoute>
          }
        />
        <Route
          path="/admin/users/:userId"
          element={
            <AdminRoute>
              <AdminUserScreen />
            </AdminRoute>
          }
        />
        <Route
          path="/admin/places"
          element={
            <AdminRoute>
              <AdminPlacesScreen />
            </AdminRoute>
          }
        />
        <Route
          path="/admin/places/:placeId"
          element={
            <AdminRoute>
              <AdminPlaceScreen />
            </AdminRoute>
          }
        />
        <Route
          path="/yatras"
          element={
            <ProtectedRoute>
              <YatrasScreen />
            </ProtectedRoute>
          }
        />
        <Route
          path="/yatras/:yatraId"
          element={
            <ProtectedRoute>
              <YatraScreen />
            </ProtectedRoute>
          }
        />
        <Route
          path="/yatras/:yatraId/attendance"
          element={
            <ProtectedRoute>
              <YatraAttendanceScreen />
            </ProtectedRoute>
          }
        />
        <Route
          path="/admin/yatras"
          element={
            <AdminRoute>
              <YatrasScreen admin />
            </AdminRoute>
          }
        />
        <Route
          path="/admin/yatras/:yatraId"
          element={
            <AdminRoute>
              <YatraScreen admin />
            </AdminRoute>
          }
        />
        <Route
          path="/admin/districts"
          element={
            <AdminRoute>
              <DistrictsScreen />
            </AdminRoute>
          }
        />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </div>
  )
}

export default function App() {
  const location = useLocation()
  const { uid } = useSession()
  const showNav =
    Boolean(uid) &&
    (location.pathname === '/' ||
      location.pathname === '/profile' ||
      location.pathname === '/check-in' ||
      location.pathname.startsWith('/admin') ||
      location.pathname === '/yatras' ||
      location.pathname.startsWith('/yatras/'))

  return (
    <AppShell showNav={showNav}>
      <AppRoutes />
    </AppShell>
  )
}
