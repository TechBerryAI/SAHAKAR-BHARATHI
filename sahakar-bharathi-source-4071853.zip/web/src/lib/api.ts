import {
  applyAuthenticated,
  clearSession,
  getAccessToken,
  getSnapshot,
  markReady,
  markRestoreFailed,
  markRestoring,
  setAccessToken,
} from './session.ts'
import type { AppCopy } from './copy.ts'
import { fetchWithColdStart } from './network.ts'
import type {
  AdminAttendanceList,
  AdminUserDetail,
  AdminUserList,
  AttendanceList,
  AttendanceRecord,
  PhoneVerificationConfirmed,
  PhoneVerificationCreated,
  Place,
  PlaceList,
  Profile,
  ProfileUpdate,
  RegistrationCreate,
  SessionResponse,
  UserRole,
} from './types.ts'
import type {
  AdministratorBrief,
  District,
  DistrictPage,
  ProtocolDocument,
  ProtocolItem,
  YatraCounterDetail,
  YatraCounterPage,
  YatraDetail,
  YatraFieldAttendance,
  YatraPage,
  YatraPositionPage,
  YatraRoute,
  YatraStop,
  YatraTracker,
  YatraTrackerCreated,
  YatraTrackerPage,
  LatestPosition,
} from './yatra.ts'

export class ApiError extends Error {
  status: number

  constructor(status: number, message: string) {
    super(message)
    this.status = status
    this.name = 'ApiError'
  }
}

// The account was created but the follow-up sign-in failed. Retrying registration
// would only hit "account already exists", so the participant must sign in instead.
export class RegisteredButSignInFailedError extends ApiError {
  loginId: string

  constructor(loginId: string, cause: ApiError) {
    super(cause.status, cause.message)
    this.loginId = loginId
    this.name = 'RegisteredButSignInFailedError'
  }
}

// The API sends English error details; show the known ones in the chosen language.
const SERVER_MESSAGES: Record<string, keyof AppCopy> = {
  'An account with these details already exists.': 'duplicateAccount',
  'An account already exists for this mobile number.': 'mobileRegistered',
  'An account already exists with this email address.': 'emailRegistered',
  'Mobile number or PIN is incorrect.': 'invalidCredentials',
  'Too many attempts. Try again later.': 'tooManyAttempts',
  'That booth was not found.': 'boothNotFound',
  'This booth is not accepting check-ins.': 'boothInactive',
  'Enter the 6-digit booth code.': 'boothCodeInvalid',
  'That counter was not found.': 'counterNotFound',
  'This counter is not accepting attendance.': 'counterInactive',
  'This Yatra is not accepting attendance.': 'yatraClosed',
  'That QR code is not a counter.': 'counterQrInvalid',
  'Accuracy is too large.': 'accuracyTooLarge',
  'That position is in the future.': 'positionInFuture',
  'That position is too old.': 'positionTooOld',
  'This Yatra is not accepting positions.': 'yatraNotTracking',
  'That stop is not on this Yatra.': 'stopNotOnYatra',
  'A counter with this code already exists.': 'counterCodeTaken',
  'This Yatra is archived.': 'yatraArchived',
  'Session is invalid or expired.': 'sessionInvalid',
  'The code is incorrect or has expired.': 'otpInvalid',
  'Verify this mobile number before registering.': 'verificationExpired',
  'Could not send the SMS. Please try again.': 'otpSendFailed',
  'Please try again in a moment.': 'pleaseWait',
}

/** Which known error this is, so a screen can react to it (not just show its text). */
export function apiErrorKey(err: unknown): keyof AppCopy | null {
  if (!(err instanceof ApiError)) return null
  if (err.status === 0) return 'networkError'
  const key = SERVER_MESSAGES[err.message]
  if (key) return key
  if (err.status === 429) return 'tooManyAttempts'
  return null
}

export function apiErrorText(err: unknown, copy: AppCopy, fallback: string): string {
  const key = apiErrorKey(err)
  return key ? copy[key] : fallback
}

const LOOPBACK_HOSTS = new Set(['localhost', '127.0.0.1', '::1', '0.0.0.0'])

/**
 * In dev, a loopback API URL is served by the Vite proxy as a same-origin `/api`
 * path. The page is opened from Windows while the API runs in WSL, and a browser
 * call straight to 127.0.0.1:8000 is a cross-origin preflight that fails.
 */
export function resolveApiBase(raw: string | undefined, dev: boolean): string {
  const trimmed = raw?.trim() ?? ''
  if (!trimmed) {
    if (dev) return ''
    throw new Error(
      'Missing VITE_API_BASE_URL. Copy web/.env.example to web/.env.local for local development.',
    )
  }
  const base = trimmed.replace(/\/+$/, '')
  if (!dev) return base
  try {
    const host = new URL(base).hostname.toLowerCase().replace(/^\[|\]$/g, '')
    if (LOOPBACK_HOSTS.has(host)) return ''
  } catch {
    return base
  }
  return base
}

// Production builds are validated in vite.config.ts; this is the runtime value.
export const API_BASE_URL = resolveApiBase(import.meta.env.VITE_API_BASE_URL, import.meta.env.DEV)

function asString(value: unknown): string | null {
  return typeof value === 'string' && value.length ? value : null
}

function asRole(value: unknown): UserRole {
  if (value === 'admin' || value === 'super_admin' || value === 'participant') return value
  return 'participant'
}

export function isStaffRole(role: string | undefined): boolean {
  return role === 'admin' || role === 'super_admin'
}

export function profileFromPayload(data: Record<string, unknown>): Profile {
  return {
    login_id: String(data.login_id ?? ''),
    full_name: String(data.full_name ?? ''),
    mobile: String(data.mobile ?? ''),
    email: asString(data.email),
    gender: asString(data.gender),
    date_of_birth: asString(data.date_of_birth),
    occupation: asString(data.occupation),
    address_line: asString(data.address_line),
    locality: asString(data.locality),
    district: asString(data.district),
    state: asString(data.state),
    pincode: asString(data.pincode),
    status: String(data.status ?? 'active'),
    role: asRole(data.role),
  }
}

function messageFromDetail(payload: unknown, fallback: string): string {
  if (!payload || typeof payload !== 'object' || !('detail' in payload)) {
    return fallback
  }
  const detail = (payload as { detail: unknown }).detail
  if (typeof detail === 'string' && detail.trim()) {
    return detail
  }
  if (Array.isArray(detail) && detail.length > 0) {
    const first = detail[0]
    if (first && typeof first === 'object' && 'msg' in first) {
      const msg = (first as { msg?: unknown }).msg
      if (typeof msg === 'string' && msg.trim()) {
        return msg.trim().replace(/^Value error,\s*/, '')
      }
    }
  }
  return fallback
}

async function parseJson(response: Response): Promise<unknown> {
  const raw = await response.text()
  if (!raw) return null
  try {
    return JSON.parse(raw)
  } catch {
    return null
  }
}

type RequestOptions = {
  method?: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE'
  body?: unknown
  auth?: boolean
  fallback: string
}

async function request<T>(path: string, options: RequestOptions): Promise<T> {
  const headers: Record<string, string> = {}
  if (options.body !== undefined) {
    headers['Content-Type'] = 'application/json'
  }
  const requiresAuth = options.auth !== false
  if (requiresAuth) {
    const token = getAccessToken()
    if (!token) {
      clearSession()
      throw new ApiError(401, 'Authentication required.')
    }
    headers.Authorization = `Bearer ${token}`
  }

  let response: Response
  try {
    response = await fetchWithColdStart(`${API_BASE_URL}${path}`, {
      method: options.method ?? 'GET',
      headers,
      body: options.body === undefined ? undefined : JSON.stringify(options.body),
    })
  } catch {
    throw new ApiError(0, 'The server could not be reached. Check your connection.')
  }

  if (response.status === 204) {
    return undefined as T
  }

  const payload = await parseJson(response)
  if (!response.ok) {
    if (response.status === 401 && requiresAuth) {
      clearSession()
    }
    throw new ApiError(response.status, messageFromDetail(payload, options.fallback))
  }
  return payload as T
}

export function sendPhoneVerification(mobile: string): Promise<PhoneVerificationCreated> {
  return request<PhoneVerificationCreated>('/api/v1/phone-verifications', {
    method: 'POST',
    body: { mobile },
    auth: false,
    fallback: 'Could not send the verification code.',
  })
}

export function confirmPhoneVerification(
  challengeId: string,
  code: string,
): Promise<PhoneVerificationConfirmed> {
  return request<PhoneVerificationConfirmed>(`/api/v1/phone-verifications/${challengeId}/confirm`, {
    method: 'POST',
    body: { code },
    auth: false,
    fallback: 'Could not verify the code.',
  })
}

// Sign-in and app start already load the profile; screens mounting right after reuse it
// instead of repeating GET /me, which costs several database round-trips on the server.
const PROFILE_FRESH_MS = 30_000
let profileLoadedAt = 0
let profileRequest: Promise<Profile> | null = null

function rememberProfile(payload: Record<string, unknown>): Profile {
  const profile = profileFromPayload(payload)
  profileLoadedAt = Date.now()
  applyAuthenticated(profile)
  return profile
}

export function getMe(options: { fresh?: boolean } = {}): Promise<Profile> {
  if (!options.fresh) {
    const cached = getSnapshot().profile
    if (cached && Date.now() - profileLoadedAt < PROFILE_FRESH_MS) {
      return Promise.resolve(cached)
    }
    if (profileRequest) return profileRequest
  }
  const pending = request<Record<string, unknown>>('/api/v1/me', {
    fallback: 'Could not load profile.',
  }).then(rememberProfile)
  profileRequest = pending
  const settle = () => {
    if (profileRequest === pending) profileRequest = null
  }
  pending.then(settle, settle)
  return pending
}

export async function updateMe(body: ProfileUpdate): Promise<Profile> {
  const payload = await request<Record<string, unknown>>('/api/v1/me', {
    method: 'PATCH',
    body,
    fallback: 'Could not update profile.',
  })
  return rememberProfile(payload)
}

export async function signIn(identifier: string, pin: string): Promise<Profile> {
  const session = await request<SessionResponse>('/api/v1/sessions', {
    method: 'POST',
    body: { identifier: identifier.trim(), pin },
    auth: false,
    fallback: 'Sign in failed.',
  })
  setAccessToken(session.access_token)
  // The session response already carries the full profile, so there is no /me round trip;
  // it also primes the cache so the home screen does not fetch /me either.
  return rememberProfile(session)
}

export async function registerAndSignIn(body: RegistrationCreate): Promise<Profile> {
  const created = await request<{ login_id: string }>('/api/v1/registrations', {
    method: 'POST',
    body,
    auth: false,
    fallback: 'Registration failed.',
  })
  try {
    return await signIn(body.mobile, body.pin)
  } catch (err) {
    const cause = err instanceof ApiError ? err : new ApiError(0, 'Sign in failed.')
    throw new RegisteredButSignInFailedError(created.login_id, cause)
  }
}

export function listAdminUsers(query: string, offset = 0): Promise<AdminUserList> {
  const params = new URLSearchParams({ limit: '20', offset: String(offset) })
  const trimmed = query.trim()
  if (trimmed) params.set('q', trimmed)
  return request<AdminUserList>(`/api/v1/admin/users?${params.toString()}`, {
    fallback: 'Could not load registered users.',
  })
}

export function getAdminUser(id: string): Promise<AdminUserDetail> {
  return request<AdminUserDetail>(`/api/v1/admin/users/${id}`, {
    fallback: 'Could not load this person.',
  })
}

export function listPlaces(offset = 0): Promise<PlaceList> {
  const params = new URLSearchParams({ limit: '50', offset: String(offset) })
  return request<PlaceList>(`/api/v1/admin/places?${params.toString()}`, {
    fallback: 'Could not load booths.',
  })
}

export function getPlace(id: string): Promise<Place> {
  return request<Place>(`/api/v1/admin/places/${id}`, {
    fallback: 'Could not load this booth.',
  })
}

export function createPlace(name: string): Promise<Place> {
  return request<Place>('/api/v1/admin/places', {
    method: 'POST',
    body: { name },
    fallback: 'Could not create this booth.',
  })
}

export function updatePlace(id: string, body: { name?: string; active?: boolean }): Promise<Place> {
  return request<Place>(`/api/v1/admin/places/${id}`, {
    method: 'PATCH',
    body,
    fallback: 'Could not update this booth.',
  })
}

export function checkIn(code: string, source: 'qr' | 'code'): Promise<AttendanceRecord> {
  return request<AttendanceRecord>('/api/v1/attendance', {
    method: 'POST',
    body: { code, source },
    fallback: 'Attendance could not be recorded.',
  })
}

export function myAttendance(offset = 0): Promise<AttendanceList> {
  const params = new URLSearchParams({ limit: '50', offset: String(offset) })
  return request<AttendanceList>(`/api/v1/attendance?${params.toString()}`, {
    fallback: 'Check-in history could not be loaded.',
  })
}

export function listPlaceAttendance(id: string, offset = 0): Promise<AdminAttendanceList> {
  const params = new URLSearchParams({ limit: '50', offset: String(offset) })
  return request<AdminAttendanceList>(`/api/v1/admin/places/${id}/attendance?${params.toString()}`, {
    fallback: 'Could not load attendance.',
  })
}

export function setAdminUserRole(id: string, role: 'admin' | 'participant'): Promise<AdminUserDetail> {
  return request<AdminUserDetail>(`/api/v1/admin/users/${id}/role`, {
    method: 'POST',
    body: { role },
    fallback: 'Could not update access.',
  })
}

export function listDistricts(offset = 0): Promise<DistrictPage> {
  const params = new URLSearchParams({ limit: '50', offset: String(offset) })
  return request<DistrictPage>(`/api/v1/admin/districts?${params.toString()}`, {
    fallback: 'Could not load districts.',
  })
}

export function createDistrict(body: { name: string; code: string; state_name?: string }): Promise<District> {
  return request<District>('/api/v1/admin/districts', {
    method: 'POST',
    body,
    fallback: 'Could not create this district.',
  })
}

export function updateDistrict(
  id: string,
  body: { name?: string; state_name?: string; active?: boolean },
): Promise<District> {
  return request<District>(`/api/v1/admin/districts/${id}`, {
    method: 'PATCH',
    body,
    fallback: 'Could not update this district.',
  })
}

export function assignDistrictAdmin(districtId: string, userId: string): Promise<District> {
  return request<District>(`/api/v1/admin/districts/${districtId}/administrators`, {
    method: 'POST',
    body: { user_id: userId },
    fallback: 'Could not assign this district administrator.',
  })
}

export function removeDistrictAdmin(districtId: string, userId: string): Promise<void> {
  return request<void>(`/api/v1/admin/districts/${districtId}/administrators/${userId}`, {
    method: 'DELETE',
    fallback: 'Could not remove this district administrator.',
  })
}

export function listYatras(query: string, status: string, offset = 0): Promise<YatraPage> {
  const params = new URLSearchParams({ limit: '20', offset: String(offset) })
  const trimmed = query.trim()
  if (trimmed) params.set('q', trimmed)
  if (status) params.set('status', status)
  return request<YatraPage>(`/api/v1/yatras?${params.toString()}`, {
    fallback: 'Could not load Yatras.',
  })
}

export function getYatra(id: string): Promise<YatraDetail> {
  return request<YatraDetail>(`/api/v1/yatras/${id}`, {
    fallback: 'Could not load this Yatra.',
  })
}

export function listCounters(yatraId: string): Promise<YatraCounterPage> {
  return request<YatraCounterPage>(`/api/v1/yatras/${yatraId}/counters?limit=50&offset=0`, {
    fallback: 'Could not load counters.',
  })
}

export function createCounter(
  yatraId: string,
  body: { name: string; code: string; description?: string },
): Promise<YatraCounterDetail> {
  return request<YatraCounterDetail>(`/api/v1/yatras/${yatraId}/counters`, {
    method: 'POST',
    body,
    fallback: 'Could not create this counter.',
  })
}

export function getCounter(yatraId: string, counterId: string): Promise<YatraCounterDetail> {
  return request<YatraCounterDetail>(`/api/v1/yatras/${yatraId}/counters/${counterId}`, {
    fallback: 'Could not load this counter.',
  })
}

export function setCounterActive(yatraId: string, counterId: string, active: boolean): Promise<YatraCounterDetail> {
  const action = active ? 'activate' : 'deactivate'
  return request<YatraCounterDetail>(`/api/v1/yatras/${yatraId}/counters/${counterId}/${action}`, {
    method: 'POST',
    fallback: 'Could not update this counter.',
  })
}

export function scanYatraAttendance(yatraId: string, qrToken: string): Promise<YatraFieldAttendance> {
  return request<YatraFieldAttendance>(`/api/v1/yatras/${yatraId}/attendance`, {
    method: 'POST',
    body: { qr_token: qrToken },
    fallback: 'Attendance could not be recorded.',
  })
}

export function listTrackers(yatraId: string): Promise<YatraTrackerPage> {
  return request<YatraTrackerPage>(`/api/v1/yatras/${yatraId}/trackers?limit=50&offset=0`, {
    fallback: 'Could not load trackers.',
  })
}

export function createTracker(yatraId: string, label: string): Promise<YatraTrackerCreated> {
  return request<YatraTrackerCreated>(`/api/v1/yatras/${yatraId}/trackers`, {
    method: 'POST',
    body: { label },
    fallback: 'Could not assign a tracker.',
  })
}

export function revokeTracker(yatraId: string, trackerId: string): Promise<YatraTracker> {
  return request<YatraTracker>(`/api/v1/yatras/${yatraId}/trackers/${trackerId}/revoke`, {
    method: 'POST',
    fallback: 'Could not revoke this tracker.',
  })
}

export function getLatestPosition(yatraId: string): Promise<LatestPosition> {
  return request<LatestPosition>(`/api/v1/yatras/${yatraId}/position`, {
    fallback: 'Could not load the latest position.',
  })
}

export function listPositions(yatraId: string, offset = 0): Promise<YatraPositionPage> {
  return request<YatraPositionPage>(`/api/v1/yatras/${yatraId}/positions?limit=50&offset=${offset}`, {
    fallback: 'Could not load position history.',
  })
}

export function createYatra(body: {
  name: string
  description?: string
  district_id: string
  starts_at: string
  ends_at: string
}): Promise<YatraDetail> {
  return request<YatraDetail>('/api/v1/yatras', {
    method: 'POST',
    body,
    fallback: 'Could not create this Yatra.',
  })
}

export function updateYatra(
  id: string,
  body: { name?: string; description?: string; starts_at?: string; ends_at?: string },
): Promise<YatraDetail> {
  return request<YatraDetail>(`/api/v1/yatras/${id}`, {
    method: 'PATCH',
    body,
    fallback: 'Could not update this Yatra.',
  })
}

export function changeYatraStatus(id: string, status: string): Promise<YatraDetail> {
  return request<YatraDetail>(`/api/v1/yatras/${id}/status`, {
    method: 'POST',
    body: { status },
    fallback: 'Could not change the Yatra status.',
  })
}

export function publishYatra(id: string): Promise<YatraDetail> {
  return request<YatraDetail>(`/api/v1/yatras/${id}/publish`, {
    method: 'POST',
    fallback: 'Could not publish this Yatra.',
  })
}

export function assignYatraAdmin(yatraId: string, userId: string): Promise<AdministratorBrief> {
  return request<AdministratorBrief>(`/api/v1/yatras/${yatraId}/administrators`, {
    method: 'POST',
    body: { user_id: userId },
    fallback: 'Could not assign this Yatra administrator.',
  })
}

export function removeYatraAdmin(yatraId: string, userId: string): Promise<void> {
  return request<void>(`/api/v1/yatras/${yatraId}/administrators/${userId}`, {
    method: 'DELETE',
    fallback: 'Could not remove this Yatra administrator.',
  })
}

export function createStop(
  yatraId: string,
  body: { name: string; address?: string; latitude?: number; longitude?: number },
): Promise<YatraStop> {
  return request<YatraStop>(`/api/v1/yatras/${yatraId}/stops`, {
    method: 'POST',
    body,
    fallback: 'Could not add this stop.',
  })
}

export function deleteStop(yatraId: string, stopId: string): Promise<void> {
  return request<void>(`/api/v1/yatras/${yatraId}/stops/${stopId}`, {
    method: 'DELETE',
    fallback: 'Could not remove this stop.',
  })
}

export function getYatraRoute(yatraId: string): Promise<YatraRoute> {
  return request<YatraRoute>(`/api/v1/yatras/${yatraId}/route`, {
    fallback: 'Could not load the route.',
  })
}

export function updateYatraRoute(yatraId: string, body: { label?: string; geometry?: string }): Promise<YatraRoute> {
  return request<YatraRoute>(`/api/v1/yatras/${yatraId}/route`, {
    method: 'PUT',
    body,
    fallback: 'Could not update the route.',
  })
}

export function listProtocol(yatraId: string): Promise<{ items: ProtocolItem[] }> {
  return request<{ items: ProtocolItem[] }>(`/api/v1/yatras/${yatraId}/protocol`, {
    fallback: 'Could not load the checklist.',
  })
}

export function createProtocolItem(
  yatraId: string,
  body: { category: string; title: string; description?: string; required: boolean },
): Promise<ProtocolItem> {
  return request<ProtocolItem>(`/api/v1/yatras/${yatraId}/protocol/items`, {
    method: 'POST',
    body,
    fallback: 'Could not add this checklist item.',
  })
}

export function submitProtocolItem(yatraId: string, itemId: string): Promise<ProtocolItem> {
  return request<ProtocolItem>(`/api/v1/yatras/${yatraId}/protocol/items/${itemId}/submit`, {
    method: 'POST',
    fallback: 'Could not submit this item.',
  })
}

export function reviewProtocolItem(yatraId: string, itemId: string): Promise<ProtocolItem> {
  return request<ProtocolItem>(`/api/v1/yatras/${yatraId}/protocol/items/${itemId}/review`, {
    method: 'POST',
    fallback: 'Could not start the review.',
  })
}

export function approveProtocolItem(yatraId: string, itemId: string): Promise<ProtocolItem> {
  return request<ProtocolItem>(`/api/v1/yatras/${yatraId}/protocol/items/${itemId}/approve`, {
    method: 'POST',
    fallback: 'Could not approve this item.',
  })
}

export function rejectProtocolItem(yatraId: string, itemId: string, reason: string): Promise<ProtocolItem> {
  return request<ProtocolItem>(`/api/v1/yatras/${yatraId}/protocol/items/${itemId}/reject`, {
    method: 'POST',
    body: { reason },
    fallback: 'Could not reject this item.',
  })
}

export async function uploadProtocolDocument(yatraId: string, itemId: string, file: File): Promise<ProtocolDocument> {
  const token = getAccessToken()
  if (!token) {
    clearSession()
    throw new ApiError(401, 'Authentication required.')
  }
  let response: Response
  try {
    response = await fetch(`${API_BASE_URL}/api/v1/yatras/${yatraId}/protocol/items/${itemId}/documents`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': file.type || 'application/octet-stream',
        'X-Document-Filename': file.name,
      },
      body: file,
    })
  } catch {
    throw new ApiError(0, 'The server could not be reached. Check your connection.')
  }
  const payload = await parseJson(response)
  if (!response.ok) {
    if (response.status === 401) clearSession()
    throw new ApiError(response.status, messageFromDetail(payload, 'Could not upload this document.'))
  }
  return payload as ProtocolDocument
}

export async function downloadProtocolDocument(
  yatraId: string,
  itemId: string,
  documentId: string,
  filename: string,
): Promise<void> {
  const token = getAccessToken()
  if (!token) {
    clearSession()
    throw new ApiError(401, 'Authentication required.')
  }
  const response = await fetch(
    `${API_BASE_URL}/api/v1/yatras/${yatraId}/protocol/items/${itemId}/documents/${documentId}`,
    { headers: { Authorization: `Bearer ${token}` } },
  )
  if (!response.ok) {
    const payload = await parseJson(response)
    if (response.status === 401) clearSession()
    throw new ApiError(response.status, messageFromDetail(payload, 'Could not download this document.'))
  }
  const blob = await response.blob()
  const url = URL.createObjectURL(blob)
  const link = document.createElement('a')
  link.href = url
  link.download = filename
  link.click()
  URL.revokeObjectURL(url)
}

export async function logout(): Promise<void> {
  const token = getAccessToken()
  clearSession()
  if (!token) return
  try {
    await fetch(`${API_BASE_URL}/api/v1/sessions/current`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` },
      // Let the revoke finish even if the page navigates or closes right away.
      keepalive: true,
    })
  } catch {
    // Local session is already cleared.
  }
}

export async function restoreSession(): Promise<void> {
  if (!getAccessToken()) {
    markReady()
    return
  }
  markRestoring()
  try {
    await getMe({ fresh: true })
  } catch (err) {
    if (err instanceof ApiError && err.status === 401) {
      // request() already cleared the rejected session.
      return
    }
    // Offline or server error: keep the token and let the participant retry
    // instead of silently presenting the signed-out start screen.
    markRestoreFailed()
  }
}
